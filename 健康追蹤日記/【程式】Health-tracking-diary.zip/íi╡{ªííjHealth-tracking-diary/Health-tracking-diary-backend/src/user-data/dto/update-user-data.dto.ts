export class UpdateUserDataDto {
  readonly name: string;
  readonly facebookUID: string;
  readonly twitterUID: string;
  readonly profilePhotoUrl: string;
}
