class ResAdminGroupData:
    def __init__(self, admingroupId, admingroupname) -> None:
        self.admingroupId = admingroupId,
        self.admingroupname = admingroupname