from django.urls import path
from . import views

urlpatterns = [
    path('repairorders/index/', views.index),
    path('repairorders/getData/', views.getData),
    path('repairorders/edit/<int:repairorderId>', views.edit),
    path('repairorders/update/', views.update),
    path('repairorders/delete/<int:repairorderId>', views.delete),
]