import json
from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.contrib.sessions.models import Session
from django.core import serializers
from admins.services import getAdminDataList
from admins.services import getAdminData
from admins.services import insertAdminData
from admins.services import updateAdminData
from admins.services import deleteAdminData
from admins.services import getAdminGroupList
from admins.requests.requpdateadmindata import ReqUpdateAdminData
from admins.requests.reqinsertadmindata import ReqInsertAdminData
import admins.models

# Create your views here.
def index(request):
    if 'adminId' in request.session:
        return render(request, 'admins/index.html')
    else:
        return redirect('/login')

def getData(request):
    if 'adminId' in request.session:
        resDataList = []
        resData = getAdminDataList()
        for item in resData.data:
            itemInfo = {
                "adminId": item.adminId,
                "adminname": item.adminname,
                "admingroupId": item.admingroupId,
                "admingroupname": item.admingroupname
            }
            resDataList.append(itemInfo)
        dataDic = {}
        dataDic['data'] = resDataList
        return HttpResponse(json.dumps(dataDic))
    else:
        return redirect('/login')

def add(request):
    if 'adminId' in request.session:
        resAdminGroupData = getAdminGroupList()
        return render(request,'admins/add.html', {'resAdminGroupData': resAdminGroupData.data})
    else:
        return redirect('/login')

def edit(request, adminId):
    if 'adminId' in request.session:
        resAdminData = getAdminData(adminId)
        resAdminGroupData = getAdminGroupList()
        return render(request,'admins/edit.html', {'resAdminData': resAdminData.data, 'resAdminGroupData': resAdminGroupData.data})
    else:
        return redirect('/login')

def insert(request):
    if 'adminId' in request.session:
        if request.method == 'POST' and request.POST:
            adminname = request.POST.get('adminname', '')
            admingroupId = request.POST.get('admingroupId', '')
            username = request.POST.get('username', '')
            password = request.POST.get('password', '')
            reqData = ReqInsertAdminData(adminname, admingroupId, username, password)
            resData = insertAdminData(reqData)
            if(resData.isSuccess):
                return redirect('/admins/index')
            else:
                return redirect('/admins/index')
        return redirect('/admins/index')
    else:
        return redirect('/login')

def update(request):
    if 'adminId' in request.session:
        if request.method == 'POST' and request.POST:            
            adminId = request.POST.get('adminId', '')            
            adminname = request.POST.get('adminname', '')
            admingroupId = request.POST.get('admingroupId', '')
            reqData = ReqUpdateAdminData(adminId, adminname, admingroupId)
            resData = updateAdminData(reqData)
            if(resData.isSuccess):
                return redirect('/admins/index')
            else:
                return redirect('/admins/index')
        return redirect('/admins/index')
    else:
        return redirect('/login')

def delete(request, adminId):
    if 'adminId' in request.session:
        deleteAdminData(adminId)
        return redirect('/admins/index')
    else:
        return redirect('/login')