module.exports = {
  i18n: {
    defaultLocale: "zh-TW",
    locales: ["en", "zh-TW"],
  },
  fallbackLng: "zh-TW",
};
