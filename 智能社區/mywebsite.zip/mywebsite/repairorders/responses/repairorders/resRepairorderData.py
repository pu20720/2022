class ResRepairorderData:
    def __init__(self, repairorderId, reserveTime, reserveQuantity, repaircompanyname, repaircategoryname, membername, price):
        self.repairorderId = repairorderId,
        self.reserveTime = reserveTime,
        self.reserveQuantity = reserveQuantity,
        self.repaircompanyname = repaircompanyname,
        self.repaircategoryname = repaircategoryname,
        self.membername = membername,
        self.price = price,