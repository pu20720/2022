class ResAdminData:
    def __init__(self, adminId, username, password, adminname, admingroupId, admingroupname) -> None:
        self.adminId = adminId,
        self.username = username,
        self.password = password,
        self.adminname = adminname,
        self.admingroupId = admingroupId,
        self.admingroupname = admingroupname