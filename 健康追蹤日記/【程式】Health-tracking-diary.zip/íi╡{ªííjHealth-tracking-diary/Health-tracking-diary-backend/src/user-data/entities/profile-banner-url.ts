export class ProfileBannerUrl {
  profileCoverUrl: string;
}
