import json
from datetime import datetime, timedelta
from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.contrib.sessions.models import Session
from django.core import serializers
from recognitionrecords.services import getRecognitionrecordDataList

# Create your views here.
def index(request):
    if 'adminId' in request.session:
        return render(request, 'recognitionrecords/index.html')
    else:
        return redirect('/login')

def getData(request):
    if 'adminId' in request.session:
        resDataList = []
        resData = getRecognitionrecordDataList()
        for item in resData.data:
            itemInfo = {
                "membername": item.membername,
                "resolution": item.resolution,                
                "imgPath": item.imgPath,
                "createTime": f"{item.createTime[0].strftime('%Y-%m-%d %H:%M')}"
            }
            resDataList.append(itemInfo)
        dataDic = {}
        dataDic['data'] = resDataList
        return HttpResponse(json.dumps(dataDic))
    else:
        return redirect('/login')