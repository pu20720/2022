export class GoogleFitTarget {
  type: '心肺強化分數' | '步數';
  value: number;
}
