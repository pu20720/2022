-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: mywebsite
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `abouts`
--

DROP TABLE IF EXISTS `abouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `abouts` (
  `aboutId` int NOT NULL AUTO_INCREMENT,
  `content` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `isEnable` bit(1) DEFAULT NULL,
  `createTime` datetime DEFAULT NULL,
  PRIMARY KEY (`aboutId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abouts`
--

LOCK TABLES `abouts` WRITE;
/*!40000 ALTER TABLE `abouts` DISABLE KEYS */;
INSERT INTO `abouts` VALUES (1,'                                    <p style=\"box-sizing: inherit; margin-right: 0px; margin-bottom: 2rem; margin-left: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 21.3333px; line-height: inherit; font-family: &quot;Source Sans Pro&quot;, sans-serif; vertical-align: baseline;\"><font color=\"#ff9c00\">現今，人們致力於將日常的生活瑣事從各方面與科技融合以帶來更為便捷之生活，因此我們決定將網路管理、資料庫、人臉辨識等技術，帶入社區生活中，營造一個更為舒適的生活圈。</font></p><p style=\"box-sizing: inherit; margin-right: 0px; margin-bottom: 2rem; margin-left: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 21.3333px; line-height: inherit; font-family: &quot;Source Sans Pro&quot;, sans-serif; vertical-align: baseline;\"><font color=\"#ff9c00\">1.人臉辨識　人員出入之檢視，社區安全係數更上一層樓。</font></p><p style=\"box-sizing: inherit; margin-right: 0px; margin-bottom: 2rem; margin-left: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 21.3333px; line-height: inherit; font-family: &quot;Source Sans Pro&quot;, sans-serif; vertical-align: baseline;\"><font color=\"#ff9c00\">2.社區網站　人人一組註冊會員，交易紀錄、可預約時間資訊檢視更為便利。</font></p><p style=\"box-sizing: inherit; margin-right: 0px; margin-bottom: 2rem; margin-left: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 21.3333px; line-height: inherit; font-family: &quot;Source Sans Pro&quot;, sans-serif; vertical-align: baseline;\"><font color=\"#ff9c00\">3.預約服務　社區公設之預約或居家用品的修繕服務，預約到府、包商統一。</font></p><p style=\"box-sizing: inherit; margin-right: 0px; margin-bottom: 2rem; margin-left: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 21.3333px; line-height: inherit; font-family: \" source=\"\" sans=\"\" pro\",=\"\" sans-serif;=\"\" vertical-align:=\"\" baseline;\"=\"\"><font style=\"background-color: rgb(255, 255, 255);\" color=\"#ffff00\"></font></p><p style=\"box-sizing: inherit; margin-right: 0px; margin-bottom: 2rem; margin-left: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 21.3333px; line-height: inherit; font-family: \" source=\"\" sans=\"\" pro\",=\"\" sans-serif;=\"\" vertical-align:=\"\" baseline;\"=\"\"></p>\r\n          \r\n          \r\n          ',_binary '',NULL);
/*!40000 ALTER TABLE `abouts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-13 22:58:35
