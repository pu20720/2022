const start = document.getElementById("identify_start");
const identify = document.getElementById("identify_identify");
const end = document.getElementById("identify_end");

start.addEventListener("click", () => {
    start.classList.add("disable");
    identify.classList.remove("disable");
    end.classList.remove("disable");
    
    $.ajax({
        type: "POST",
        url: $SCRIPT_ROOT + "/identify/start",
        data: "",
        success: (data) => {
            console.log(data);
        },
        contentType: false,
        processData: false,
        dataType: "json"
    });
});
identify.addEventListener("click", () => {
    $.ajax({
        type: "POST",
        url: $SCRIPT_ROOT + "/identify/identify",
        data: "",
        success: (data) => {
            showImg(data["batch"], data["index"], data["percent"]);
        },
        contentType: false,
        processData: false,
        dataType: "json"
    });
});
end.addEventListener("click", () => {
    start.classList.remove("disable");
    identify.classList.add("disable");
    end.classList.add("disable");
    
    $.ajax({
        type: "POST",
        url: $SCRIPT_ROOT + "/identify/end",
        data: "",
        success: (data) => {
            identifyReset();
        },
        contentType: false,
        processData: false,
        dataType: "json"
    });
});

function showImg(batch, index, percentage) {
    if(percentage != 0) {
        const tbody = document.getElementById("identify_imgs");
        const tr = document.createElement("tr");
        const imgfiles = ["_contour.png", ".png", "_mask.png"]

        for(const imgfile of imgfiles) {
            const img = document.createElement("img");
            const td = document.createElement("td");
            img.src = "./../../static/statis/s" + batch + "/" + (index-1) + imgfile;
            console.log(img);
            td.appendChild(img);
            tr.appendChild(td);
        }

        const td = document.createElement("td");
        td.innerText = percentage;
        tr.appendChild(td);

        tbody.appendChild(tr);
    } else {
        alert("[產線系統管理]\n辨識失敗")
    }
}

function identifyReset() {
    const tbody = document.getElementById("identify_imgs");

    while(tbody.firstElementChild) { tbody.removeChild(tbody.firstElementChild); }
}