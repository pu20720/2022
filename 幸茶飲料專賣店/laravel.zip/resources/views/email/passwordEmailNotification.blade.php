<h1>恭喜{{$nickname}}密碼更新成功</h1>
