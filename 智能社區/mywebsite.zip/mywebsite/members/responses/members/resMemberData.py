class ResMemberData:
    def __init__(self, memberId, username, membername, phone):
        self.memberId = memberId,
        self.username = username,
        self.membername = membername,
        self.phone = phone,