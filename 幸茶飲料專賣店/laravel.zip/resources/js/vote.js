function listBtn() {
    var listBtn = document.getElementById('listBtn');
    var textlistn = document.getElementById('textlistn');
    if (textlistn.style.display === 'none') {
      textlistn.style.display = 'block';
    } else {
      textlistn.style.display = 'none';
    }
  }
  function listBtn2() {
    var listBtn = document.getElementById('listBtn2');
    var textlistn = document.getElementById('textlistn2');
    if (textlistn.style.display === 'none') {
      textlistn.style.display = 'block';
    } else {
      textlistn.style.display = 'none';
    }
  }
  function listBtn3() {
    var listBtn = document.getElementById('listBtn3');
    var textlistn = document.getElementById('textlistn3');
    if (textlistn.style.display === 'none') {
      textlistn.style.display = 'block';
    } else {
      textlistn.style.display = 'none';
    }
  }
