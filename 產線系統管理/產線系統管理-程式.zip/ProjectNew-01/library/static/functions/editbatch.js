getbatch();

function getbatch() {
    $.ajax({
        type: "POST",
        url: $SCRIPT_ROOT + "/editbatch/get",
        data: "",
        success: (data) => {
            batchinfo(data["datas"]);
        },
        contentType: false,
        processData: false,
        dataType: "json"
    });
}

function batchinfo(datas) {
    const tbody = document.getElementById("editbatch_tbody");

    while(tbody.firstElementChild) { tbody.removeChild(tbody.firstElementChild); }
    
    for(const data of datas) {
        const tr = document.createElement("tr");
        const tdb = document.createElement("td");
        const button = document.createElement("button");

        button.innerText = "s" + data[0];
        tdb.appendChild(button);
        tr.appendChild(tdb);
        button.addEventListener("click", () => {
            delbatch(button.innerText);
        });

        for(let i = 1; i < 3; i++) {
            const td = document.createElement("td");

            td.appendChild(document.createTextNode(data[i]));
            tr.appendChild(td);
        }

        tbody.appendChild(tr);
    }
}

function delbatch(tablename) {
    $.ajax({
        type: "POST",
        url: $SCRIPT_ROOT + "/editbatch/del/" + tablename,
        data: "",
        success: (data) => {
            if(data["msg"] == "success") {
                alert("[產線系統管理]\n刪除成功");
                getbatch();
            } else {
                alert("[產線系統管理]\n刪除失敗");
            }
        },
        contentType: false,
        processData: false,
        dataType: "json"
    });
}