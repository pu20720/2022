file_name='r'
import torch
device=torch.device('cpu') 
num_classes=4
batch_size=1 

from torch import nn
class Simple_Model(nn.Module):
    def __init__(self):
        super().__init__()
        self.block_1=nn.Sequential(
            nn.Conv2d(in_channels=1,out_channels=32,kernel_size=2,padding=1), 
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2,stride=2), 
        )
        self.fc=nn.Sequential(
            nn.Linear(32*10*20,128),
            nn.ReLU(inplace=True),
            nn.Linear(128,num_classes),
        )
    def forward(self,x):
        x=self.block_1(x) 
        x=x.view(x.size(0),-1)
        x=self.fc(x)
        return x

classifier=Simple_Model().to(device)
classifier.load_state_dict(torch.load(file_name)) 
classifier.eval()

import pyaudio 
FORMAT=pyaudio.paInt16
CHANNELS=1 
RATE=16000 
CHUNK=1024
RECORD_SECONDS=1

mic=pyaudio.PyAudio()
print('請下指令...')
stream=mic.open(format=FORMAT,channels=CHANNELS,rate=RATE,frames_per_buffer=CHUNK,input=True)

frames=[]
for i in range(0,int(RATE/CHUNK*RECORD_SECONDS)):
    data=stream.read(CHUNK)
    frames.append(data)

print('開始動作...')

stream.stop_stream()
stream.close()
mic.terminate()

import wave
wf = wave.open('action.wav','wb')
wf.setnchannels(CHANNELS)
wf.setsampwidth(mic.get_sample_size(FORMAT))
wf.setframerate(RATE)
wf.writeframes(b''.join(frames))
wf.close()

import librosa
y,sr=librosa.load('action.wav',sr=None)

y=y[::3] 0,3
mfccs=librosa.feature.mfcc(y,sr=16000) 
import numpy as np
mfccs=np.pad(mfccs,pad_width=((0,0),(0,40-mfccs.shape[1])),mode='constant') 
np.save('action.npy',mfccs)  儲存成.n檔


import numpy
voice=torch.tensor(numpy.load('action.npy')) 
voice=voice.unsqueeze(0).unsqueeze(0) 
voice=voice.to(device)

pred=classifier(voice) pred:1
output_id=torch.max(pred,dim=1)[1] 
print(output_id)