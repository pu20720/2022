from django.http import HttpResponse
from django.shortcuts import redirect, render
from logins.requests.reqlogin import Reqlogin
from logins.responses.reslogin import Reslogin
from logins.services import getLoginData

# Create your views here.
def login(request):
    if request.method == 'POST' and request.POST:
        username = request.POST.get('username', '')
        password = request.POST.get('password', '')
        resLogin = getLoginData(Reqlogin(str(username), str(password)))
        if any(resLogin.isSuccess):
            request.session['adminId'] = resLogin.data.adminId
            request.session['adminname'] = resLogin.data.adminname
            request.session['admingroupId'] = resLogin.data.admingroupId
            return redirect('/home/')
        else:
            return render(request, 'login/index.html')
    return render(request, 'login/index.html')

def logout(request):
    del request.session['adminId']
    del request.session['adminname']
    del request.session['admingroupId']
    return redirect('/login')