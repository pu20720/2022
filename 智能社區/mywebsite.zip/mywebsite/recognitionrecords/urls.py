from django.urls import path
from . import views

urlpatterns = [
    path('recognitionrecords/index/', views.index),
    path('recognitionrecords/getData/', views.getData),
]