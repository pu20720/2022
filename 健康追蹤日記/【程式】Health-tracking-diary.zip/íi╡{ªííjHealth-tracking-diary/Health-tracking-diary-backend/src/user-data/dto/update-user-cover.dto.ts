export class UpdateUserCoverDto {
  readonly profileCoverUrl: string;
}
