import json
from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.contrib.sessions.models import Session
from django.core import serializers
from repaircompanys.services import getRepaircompanyDataList
from repaircompanys.services import getRepaircompanyData
from repaircompanys.services import insertRepaircompanyData
from repaircompanys.services import updateRepaircompanyData
from repaircompanys.services import deleteRepaircompanyData
from repaircategorys.services import getRepaircategoryDataList
from repaircompanys.requests.reqinsertrepaircompanydata import ReqInsertRepaircompanyData
from repaircompanys.requests.requpdaterepaircompanydata import ReqUpdateRepaircompanyData

# Create your views here.
def index(request):
    if 'adminId' in request.session:
        return render(request, 'repaircompanys/index.html')
    else:
        return redirect('/login')

def getData(request):
    if 'adminId' in request.session:
        resDataList = []
        resData = getRepaircompanyDataList()
        for item in resData.data:
            itemInfo = {
                "repaircompanyId": item.repaircompanyId,
                "repaircompanyname": item.repaircompanyname,
                "repaircategoryname": item.repaircategoryname,
                "openingTime": f"{item.startTime[0]}:00-{item.endTime[0]}:00"
            }
            resDataList.append(itemInfo)
        dataDic = {}
        dataDic['data'] = resDataList
        return HttpResponse(json.dumps(dataDic))
    else:
        return redirect('/login')

def add(request):
    if 'adminId' in request.session:
        timeRange = range(0, 24)
        resRapircategoryData = getRepaircategoryDataList()
        return render(request,'repaircompanys/add.html', { 'timeRange': timeRange, 'resRapircategoryData': resRapircategoryData.data })
    else:
        return redirect('/login')

def edit(request, repaircompanyId):
    if 'adminId' in request.session:
        timeRange = range(0, 24)
        resRapircategoryData = getRepaircategoryDataList()
        resRepaircompanyData = getRepaircompanyData(repaircompanyId)
        return render(request,'repaircompanys/edit.html', {'resRepaircompanyData': resRepaircompanyData.data, 'timeRange': timeRange, 'resRapircategoryData': resRapircategoryData.data })
    else:
        return redirect('/login')

def insert(request):
    if 'adminId' in request.session:
        if request.method == 'POST' and request.POST:
            repaircategoryId = request.POST.get('repaircategoryId', '')
            repaircompanyname = request.POST.get('repaircompanyname', '')
            startTime = request.POST.get('startTime', '')
            endTime = request.POST.get('endTime', '')
            reqData = ReqInsertRepaircompanyData(repaircategoryId, repaircompanyname, startTime, endTime)
            resData = insertRepaircompanyData(reqData)
            if(resData.isSuccess):
                return redirect('/repaircompanys/index')
            else:
                return redirect('/repaircompanys/index')
        return redirect('/repaircompanys/index')
    else:
        return redirect('/login')

def update(request):
    if 'adminId' in request.session:
        if request.method == 'POST' and request.POST: 
            repaircompanyId = request.POST.get('repaircompanyId', '')
            repaircategoryId = request.POST.get('repaircategoryId', '')
            repaircompanyname = request.POST.get('repaircompanyname', '')
            startTime = request.POST.get('startTime', '')
            endTime = request.POST.get('endTime', '')
            reqData = ReqUpdateRepaircompanyData(repaircompanyId, repaircategoryId, repaircompanyname, startTime, endTime)
            resData = updateRepaircompanyData(reqData)
            if(resData.isSuccess):
                return redirect('/repaircompanys/index')
            else:
                return redirect('/repaircompanys/index')
        return redirect('/repaircompanys/index')
    else:
        return redirect('/login')

def delete(request, repaircompanyId):
    if 'adminId' in request.session:
        deleteRepaircompanyData(repaircompanyId)
        return redirect('/repaircompanys/index')
    else:
        return redirect('/login')