const login_fogpasswd = document.getElementById("login_fogpasswd");
const email = document.getElementById("email");
let login_msg = document.getElementById("login_msg").value;

if(login_msg == "invalid") {alert("[產線系統管理]\n登入失敗\n帳號不存在或密碼錯誤 !");}
login_msg = ""

login_fogpasswd.addEventListener("click", () => {
    if(email.value != "") {
        const form_data = new FormData();
        form_data.append("email", email.value);
        
        $.ajax({
            type: "POST",
            url: $SCRIPT_ROOT + "/forget",
            data: form_data,
            success: (data) => {
                if(data.data == "success") {
                    alert("[產線系統管理]\n寄送成功 !");
                } else if(data.data == "fail") {
                    alert("[產線系統管理]\n寄送失敗 !");
                } else {}
            },
            contentType: false,
            processData: false,
            dataType: "json"
        });
    } else {
        alert("[產線系統管理]\n請填上信箱 !");
    }
});