class ReqUpdateFacilitycategoryData:
    def __init__(self, facilitycategoryId, facilitycategoryname, maxium, startTime, endTime):
        self.facilitycategoryId = facilitycategoryId,
        self.facilitycategoryname = facilitycategoryname,
        self.maxium = maxium,
        self.startTime = startTime,
        self.endTime = endTime