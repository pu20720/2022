from django.urls import path
from . import views

urlpatterns = [
    path('admins/index/', views.index),
    path('admins/getData/', views.getData),
    path('admins/add/', views.add),
    path('admins/insert/', views.insert),
    path('admins/edit/<int:adminId>', views.edit),
    path('admins/update/', views.update),
    path('admins/delete/<int:adminId>', views.delete),
]