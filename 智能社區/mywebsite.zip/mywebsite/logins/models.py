from django.db import models

# Create your models here.
class admins(models.Model):
    adminId = models.IntegerField(primary_key = True)
    username = models.CharField(max_length = 45, primary_key = False)
    password = models.CharField(max_length = 45, primary_key = False)
    adminname = models.CharField(max_length = 45, primary_key = False)
    admingroupId = models.IntegerField(primary_key = False)
    class Meta:
        db_table = "admins"
        managed = False