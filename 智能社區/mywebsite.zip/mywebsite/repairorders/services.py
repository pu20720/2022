from django.db import connection
from repairorders.responses.result import Result
from repairorders.responses.repairorders.resRepairorderData import ResRepairorderData

def getRepairorderDataList():
    resRepairorderDataList = list()
    cursor = connection.cursor()
    cursor.execute("""
        select repairorders.repairorderId, DATE_FORMAT(repairorders.reserveTime, "%Y-%e-%c %H:%i") as reserveTime, repairorders.reserveQuantity, repaircompanys.repaircompanyname, repaircategorys.repaircategoryname, members.membername, repairorders.price
        from repairorders
        inner join members on members.memberId = repairorders.memberId
        inner join repaircategorys on repaircategorys.repaircategoryId = repairorders.repaircategoryId
        inner join repaircompanys on repaircompanys.repaircompanyId = repairorders.repaircompanyId
        where repairorders.isEnable = 1
        order by repairorders.repairorderId asc"""
    )
    data = cursor.fetchall()
    for item in data:
        resRepairorderDataList.append(ResRepairorderData(item[0], item[1], item[2], item[3], item[4], item[5], item[6]))
    return Result(True, resRepairorderDataList, "成功取得列表")

def getRepairorderData(repairorderId):
    cursor = connection.cursor()
    cursor.execute("""
        select repairorders.repairorderId, DATE_FORMAT(repairorders.reserveTime, "%%Y-%%e-%%c %%H:%%i") as reserveTime, repairorders.reserveQuantity, repaircompanys.repaircompanyname, repaircategorys.repaircategoryname, members.membername, repairorders.price
        from repairorders
        inner join members on members.memberId = repairorders.memberId
        inner join repaircategorys on repaircategorys.repaircategoryId = repairorders.repaircategoryId
        inner join repaircompanys on repaircompanys.repaircompanyId = repairorders.repaircompanyId
        where repairorderId = %s"""
    ,[repairorderId])
    data = cursor.fetchone()
    resRepairorderData = ResRepairorderData(data[0], data[1], data[2], data[3], data[4], data[5], data[6])
    if(data == None):
        return Result(False, None, "取得資料錯誤")
    return Result(True, resRepairorderData, "成功取得資料")

def deleteRepairorderData(repairorderId):
    cursor = connection.cursor()
    cursor.execute("""
        update repairorders
        set repairorders.isEnable = 0
        where repairorderId = %(repairorderId)s"""
    ,{ 'repairorderId': repairorderId})
    return Result(True, None, "成功更新資料")

def updateRepairorderprice(repairorderId, price):
    cursor = connection.cursor()
    cursor.execute("""
        update repairorders
        set repairorders.price = %(price)s
        where repairorderId = %(repairorderId)s"""
    ,{ 'price': price, 'repairorderId': repairorderId})
    return Result(True, None, "成功更新資料")