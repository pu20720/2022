from django.urls import path
from . import views

urlpatterns = [
    path('repaircompanys/index/', views.index),
    path('repaircompanys/getData/', views.getData),
    path('repaircompanys/add/', views.add),
    path('repaircompanys/insert/', views.insert),
    path('repaircompanys/edit/<int:repaircompanyId>', views.edit),
    path('repaircompanys/update/', views.update),
    path('repaircompanys/delete/<int:repaircompanyId>', views.delete),
]