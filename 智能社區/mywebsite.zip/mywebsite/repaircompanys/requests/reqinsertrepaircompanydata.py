class ReqInsertRepaircompanyData:
    def __init__(self, repaircategoryId, repaircompanyname, startTime, endTime):
        self.repaircategoryId = repaircategoryId
        self.repaircompanyname = repaircompanyname,
        self.startTime = startTime,
        self.endTime = endTime,