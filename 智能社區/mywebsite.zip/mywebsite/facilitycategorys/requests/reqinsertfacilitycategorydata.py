class ReqInsertFacilitycategoryData:
    def __init__(self, facilitycategoryname, maxium, startTime, endTime):
        self.facilitycategoryname = facilitycategoryname,
        self.maxium = maxium,
        self.startTime = startTime,
        self.endTime = endTime