export class CreateDiaryFolderDto {
  name: string;
}
