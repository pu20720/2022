class ResRepaircompanyData:
    def __init__(self, repaircompanyId, repaircategoryId, repaircategoryname, repaircompanyname, startTime, endTime):
        self.repaircompanyId = repaircompanyId,
        self.repaircategoryId = repaircategoryId,
        self.repaircategoryname = repaircategoryname
        self.repaircompanyname = repaircompanyname,
        self.startTime = startTime,
        self.endTime = endTime,