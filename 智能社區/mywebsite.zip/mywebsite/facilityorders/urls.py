from django.urls import path
from . import views

urlpatterns = [
    path('facilityorders/index/', views.index),
    path('facilityorders/getData/', views.getData),
    path('facilityorders/delete/<int:facilityorderId>', views.delete),
]