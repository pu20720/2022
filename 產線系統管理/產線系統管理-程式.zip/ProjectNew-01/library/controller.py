import hashlib
import json
import random
import sqlite3
import string
from datetime import datetime
from flask import Flask, abort, jsonify, redirect, render_template, request, session, url_for
from flask_mail import Mail, Message
from os import environ, mkdir, path, urandom
from threading import Thread
from shutil import rmtree
from . import database

IsMotorOn = False
MotorSpeed = 128
Direct = False
Thres = 99
Batch = 1
Index = 0
Success = False

UPLOAD_FOLDER = "/path/to/the/uploads"
ALLOWED_EXTENSIONS  = {"json"}

app = Flask(__name__)
app.secret_key = urandom(32)
app.config.update(
    DEBUG=False,
    MAIL_SERVER="smtp.gmail.com",
    MAIL_PORT=465,
    MAIL_USE_SSL=True,
    MAIL_DEFAULT_SENDER=("專題", environ.get("MAIL_USERNAME")),
    MAIL_MAX_EMAILS=10,
    MAIL_USERNAME=environ.get("MAIL_USERNAME"),
    MAIL_PASSWORD=environ.get("MAIL_PASSWORD")
)
mail = Mail(app)

def getLoginDetails() -> tuple:
    if "account" not in session:
        loggedIn = False
        lastName = ""
        permission = ""
    else:
        loggedIn = True
        lastName = session["lastname"]
        permission = session["permission"]

    return (loggedIn, lastName, permission)

def isValid(email: str, passwd: str) -> bool:
    with sqlite3.connect("database.db") as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM users")
        datas = c.fetchall()
        
        for row in datas:
            if row[6] == email and row[4] == hashlib.md5(passwd.encode()).hexdigest():
                session["userID"] = row[0]
                session["firstname"] = row[1]
                session["lastname"] = row[2]
                session["account"] = row[3]
                session["birth"] = row[5]
                session["email"] = row[6]
                session["permission"] = row[7]

                return True

    return False

def allowFile(filename: str) -> bool:
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def getRandomString(length: int) -> str:
    mystr = ''.join(random.choice(string.ascii_letters) for i in range(length))
    
    return mystr

def getStatis(tablename: str) -> list:
    datas = []
    
    with sqlite3.connect("database.db") as conn:
        c = conn.cursor()

        c.execute("SELECT percentage FROM " + tablename)
        datas = c.fetchall()

    return datas

def calStatis(data: tuple) -> dict:
    global Thres
    tablename = "s" + str(data[0])
    success = 0
    fail = 0
    templists = getStatis(tablename)

    for mylist in templists:
        if mylist[0] > int(Thres):
            success += 1
        else:
            fail += 1

    return {"tablename": "s" + str(data[0]), "success": success, "fail": fail}

def sendAsyncMail(app: Flask, msg: Message) -> None:
    with app.app_context():
        mail.send(msg)

def sendEmail(email: str, passwd: str) -> None:
    print(passwd)
    
    try:
        subject = "[產線系統管理] 修改密碼"
        message = "<h2>請用以下密碼登入 再次修改密碼</h2><br><label>"+passwd+"</label>"
        msg = Message(
            subject=subject,
            recipients=[email],
            html=message
        )

        thr = Thread(target=sendAsyncMail, args=[app, msg])
        thr.start()
    except Exception as e:
        print(e)

def emailEndInfo(email: str, tablename: str) -> None:
    global Thres
    percs = getStatis(tablename)
    success = 0
    fail = 0

    for perc in percs:
        if perc[0] >= Thres:
            success += 1
        else:
            fail += 1

    try:
        subject = "[產線系統管理] 辨識結束通知"
        message = "<h2>批號: "+ tablename +"</h2><br><label style='color: #66ff66'>成功: "+ str(success) +"</label><br><label style='color: #ff66ff'>失敗: "+ str(fail) +"</label>"
        msg = Message(
            subject=subject,
            recipients=[email],
            html=message
        )
        thr = Thread(target=sendAsyncMail, args=[app, msg])
        thr.start()
    except Exception as e:
        print(e)

@app.route("/")
def index():
    loggedIn, lastName, permission = getLoginDetails()

    return render_template("index.html", loggedIn = loggedIn, lastName = lastName, permission = permission)

@app.route("/login", methods = ["GET", "POST"])
def login():
    loggedIn, lastName, permissiom = getLoginDetails()
    login_msg = ""

    if request.method == "POST":
        info = {
            "email": request.form["email"],
            "passwd": request.form["passwd"]
        }

        if isValid(info["email"], info["passwd"]):
            with sqlite3.connect("log.db") as conn:
                c = conn.cursor()

                try:
                    c.execute("INSERT INTO login (email, status, time) VALUES (?, ?, ?)", (
                        info["email"],
                        "SUCCESS",
                        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    ))
                except Exception as e:
                    conn.rollback()
                    print(e)

                conn.commit()

            return redirect(url_for("mainpage"))
        else:
            with sqlite3.connect("log.db") as conn:
                c = conn.cursor()

                try:
                    c.execute("INSERT INTO login (email, status, time) VALUES (?, ?, ?)", (
                        info["email"],
                        "FAIL",
                        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    ))
                except Exception as e:
                    conn.rollback()
                    print(e)

                conn.commit()
            
            login_msg = "invalid"

    return render_template("routes/login.html", loggedIn = loggedIn, lastName = lastName, permissiom = permissiom, login_msg = login_msg)

@app.route("/mainpage")
def mainpage():
    loggedIn, lastName, permission = getLoginDetails()
    
    if "account" in session:
        return render_template("routes/mainpage.html", loggedIn = loggedIn, permission = permission, lastName = lastName)

    return redirect(url_for("login"))

@app.route("/logout")
def logout():
    session.pop("userID", None)
    session.pop("firstname", None)
    session.pop("lastname", None)
    session.pop("account", None)
    session.pop("birth", None)
    session.pop("email", None)
    session.pop("permission", None)
    
    return redirect(url_for("login"))

@app.route("/register", methods = ["GET", "POST"])
def register():
    loggedIn, lastName, permission = getLoginDetails()
    reg_msg = ""
    datas = []

    if "account" in session:
        if request.method == "POST":
            reg_file = request.files["reg_file"]
            del_file = request.files["del_file"]
            print(reg_file.filename)
            print(del_file.filename)

            if reg_file.filename == "" and del_file.filename == "":
                reg_msg = "reg_noselfile"

            if reg_file:
                if allowFile(reg_file.filename) and reg_file.filename[:3] == "reg":
                    fdatas = json.loads(str(reg_file.read(), "utf8"))

                    with sqlite3.connect("database.db") as conn:
                        c = conn.cursor()
                        
                        try:
                            for data in fdatas:
                                testpasswd = getRandomString(10)
                                
                                c.execute("INSERT INTO users (firstname, lastname, account, passwd, birth, email, permission) VALUES (?, ?, ?, ?, ?, ?, ?)", (
                                    data["firstname"],
                                    data["lastname"], 
                                    data["account"],
                                    hashlib.md5(testpasswd.encode()).hexdigest(),
                                    data["birth"],
                                    data["email"],
                                    data["permission"]
                                ))

                                sendEmail(data["email"], testpasswd)
                        except Exception as e:
                            conn.rollback()
                            reg_msg = "reg_err"
                            print(e)

                        conn.commit()
                        reg_msg = "reg_success"
                else:
                    reg_msg = "reg_typeerr"

            if del_file:
                if allowFile(del_file.filename) and del_file.filename[:3] == "del":
                    fdatas = json.loads(str(del_file.read(), "utf8"))

                    with sqlite3.connect("database.db") as conn:
                        c = conn.cursor()

                        try:
                            for data in fdatas:
                                c.execute("DELETE FROM users WHERE userID = '"+ str(data["userID"]) +"'")
                        except Exception as e:
                            conn.rollback()
                            reg_msg = "del_err"
                            print(e)

                        reg_msg = "del_success"
                else:
                    reg_msg = "del_typeerr"
        
        with sqlite3.connect("database.db") as conn:
            c = conn.cursor()

            c.execute("SELECT * FROM users")
            datas = c.fetchall()

        if permission == 0:
            return render_template("routes/register.html", loggedIn = loggedIn, lastName = lastName, permission = permission, reg_datas = datas, reg_msg = reg_msg)
        else:
            return redirect(url_for("mainpage"))

    return redirect(url_for("login"))

@app.route("/reg_edit", methods = ["GET", "POST"])
def reg_edit():
    edit_msg = ""

    if "account" in session:
        if request.method == "POST":
            info = {
                "id": request.form["0"],
                "firstname": request.form["1"],
                "lastname": request.form["2"],
                "account": request.form["3"],
                "passwd": request.form["4"],
                "birth": request.form["5"],
                "email": request.form["6"],
                "permission": request.form["7"],
            }

            print(info)

            with sqlite3.connect("database.db") as conn:
                c = conn.cursor()
                c.execute("SELECT * FROM users WHERE email = '"+str(info["email"])+"'")
                datas = c.fetchall()

                if len(datas) <= 1:
                    try:
                        c.execute("UPDATE users SET firstname = ?, lastname = ?, account = ?, passwd = ?, birth = ?, email = ? WHERE userID = '"+str(info["id"])+"'", (
                            info["firstname"],
                            info["lastname"], 
                            info["account"],
                            info["passwd"],
                            info["birth"],
                            info["email"]
                        ))

                        conn.commit()
                        edit_msg = "edit_success"

                    except Exception as e:
                        conn.rollback()
                        edit_msg = "edit_fail"
                        print(e)
                else:
                    edit_msg = "edit_mailerr"

            with sqlite3.connect("log.db") as conn:
                c = conn.cursor()

                try:
                    c.execute("INSERT INTO edit (SMemail, USemail, time) VALUES (?, ?, ?)", (
                        session["email"],
                        info["email"],
                        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    ))
                except Exception as e:
                    conn.rollback()
                    print(e)

                conn.commit()

            return {"msg": edit_msg}

    return redirect(url_for("login"))

@app.route("/editaccount", methods = ["GET", "POST"])
def editaccount():
    loggedIn, lastName, permission = getLoginDetails()
    edit_msg = ""
    
    if "account" in session:
        if request.method == "POST":
            postinfo = {
                "firstname": request.form["edit_firstname"],
                "lastname": request.form["edit_lastname"],
                "account": request.form["edit_account"],
                "passwd": request.form["edit_passwd"],
                "passwd_r": request.form["edit_passwd_r"],
                "birth": request.form["edit_birth"],
                "email": request.form["edit_email"]
            }

            if postinfo["passwd"] == postinfo["passwd_r"]:
                with sqlite3.connect("database.db") as conn:
                    c = conn.cursor()
                    c.execute("SELECT * FROM users WHERE email = '" + postinfo["email"] + "'")
                    datas = c.fetchone()

                    if datas[0] == session["userID"]:
                        try:
                            if postinfo["passwd"] != "":
                                c.execute("UPDATE users SET firstname = ?, lastname = ?, account = ?, passwd = ?, birth = ?, email = ? WHERE userID = '"+str(session["userID"])+"'", (
                                    postinfo["firstname"],
                                    postinfo["lastname"], 
                                    postinfo["account"],
                                    hashlib.md5(postinfo["passwd"].encode()).hexdigest(),
                                    postinfo["birth"],
                                    postinfo["email"]
                                ))
                            else:
                                c.execute("UPDATE users SET firstname = ?, lastname = ?, account = ?, birth = ?, email = ? WHERE userID = '"+str(session["userID"])+"'", (
                                    postinfo["firstname"],
                                    postinfo["lastname"], 
                                    postinfo["account"],
                                    postinfo["birth"],
                                    postinfo["email"]
                                ))
                        except:
                            conn.rollback()
                            edit_msg = "edit_fail"

                        conn.commit()
                        return redirect(url_for("logout"))
                    else:
                        edit_msg = "edit_emailalready"
            else:
                edit_msg = "edit_passwderr"

        info = {
            "firstname": session["firstname"],
            "lastname": session["lastname"],
            "account": session["account"],
            "birth": session["birth"],
            "email": session["email"]
        }
        
        return render_template("routes/editaccount.html", loggedIn = loggedIn, lastName = lastName, permission = permission, info = info, edit_msg = edit_msg)

    return redirect(url_for("login"))

@app.route("/control")
def control():
    global IsMotorOn, Direct, MotorSpeed, Thres
    loggedIn, lastName, permission = getLoginDetails()
    
    if "account" in session:
        if permission <= 1:
            return render_template("routes/control.html", loggedIn = loggedIn, lastName = lastName, permission = permission, isMotorOn = IsMotorOn, direct = Direct, motorspeed = MotorSpeed, thres = Thres)
        else:
            return redirect(url_for("mainpage"))
    else:
        return redirect(url_for("login"))

@app.route("/control/motor", methods = ["GET", "POST"])
def control_motor():
    global IsMotorOn
    
    if request.method == "POST":
        IsMotorOn = not IsMotorOn

        with sqlite3.connect("log.db") as conn:
            c = conn.cursor()

            try:
                c.execute("INSERT INTO control (email, type, time) VALUES (?, ?, ?)", (
                    session["email"],
                    ("Motor change to " + str(IsMotorOn)),
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                ))
            except Exception as e:
                conn.rollback()
                print(e)

            conn.commit()

        return jsonify({"motor": IsMotorOn})

    return redirect(url_for("control"))

@app.route("/control/direct", methods = ["GET", "POST"])
def control_direct():
    global Direct
    
    if request.method == "POST":
        Direct = not Direct

        with sqlite3.connect("log.db") as conn:
            c = conn.cursor()

            try:
                c.execute("INSERT INTO control (email, type, time) VALUES (?, ?, ?)", (
                    session["email"],
                    ("Direct change to " + str(Direct)),
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                ))
            except Exception as e:
                conn.rollback()
                print(e)

            conn.commit()

        return jsonify({"direct": Direct})

    return redirect(url_for("control"))

@app.route("/control/speed", methods = ["GET", "POST"])
def control_speed():
    global MotorSpeed
    
    if request.method == "POST":
        info = {
            "speed": request.form["speed"],
        }

        MotorSpeed = int(info["speed"])

        with sqlite3.connect("log.db") as conn:
            c = conn.cursor()

            try:
                c.execute("INSERT INTO control (email, type, time) VALUES (?, ?, ?)", (
                    session["email"],
                    ("Speed change to " + str(MotorSpeed)),
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                ))
            except Exception as e:
                conn.rollback()
                print(e)

            conn.commit()

        return jsonify({"speed": MotorSpeed})

    return redirect(url_for("control"))

@app.route("/control/thres", methods = ["GET", "POST"])
def control_thres():
    global Thres
    
    if request.method == "POST":
        info = {
            "thres": request.form["thres"],
        }

        Thres = int(info["thres"])

        with sqlite3.connect("log.db") as conn:
            c = conn.cursor()

            try:
                c.execute("INSERT INTO control (email, type, time) VALUES (?, ?, ?)", (
                    session["email"],
                    ("Thres change to " + str(Thres)),
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                ))
            except Exception as e:
                conn.rollback()
                print(e)

            conn.commit()

        return jsonify({"thres": Thres})

    return redirect(url_for("control"))

@app.route("/initchartdata", methods = ["GET", "POST"])
def initChartdata():
    global Thres
    
    if request.method == "POST":
        datas = []
        lists = []
        
        with sqlite3.connect("database.db") as conn:
            c = conn.cursor()
            
            c.execute("SELECT * FROM statis ORDER BY tableID DESC")
            temps = c.fetchall()

            for temp in temps:
                c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='s"+ str(temp[0]) +"'")

                if len(c.fetchall()) != 0:
                    datas.append(temp)

        for data in datas:
            lists.append(calStatis(data))

        return jsonify({"datas": lists})

    return redirect(url_for("mainpage"))

@app.route("/getchartdata", methods = ["GET", "POST"])
def chartdata():
    datas = []
    lists = []
    
    if request.method == "POST":
        info = {
            "sdate": request.form["sdate"],
            "edate": request.form["edate"],
        }

        with sqlite3.connect("database.db") as conn:
            c = conn.cursor()

            c.execute("SELECT * FROM statis ORDER BY tableID DESC")
            temps = c.fetchall()

            for temp in temps:
                c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='s"+ str(temp[0]) +"'")

                if len(c.fetchall()) != 0:
                    datas.append(temp)

        sdatetime = datetime.strptime(info["sdate"], "%Y-%m-%dT%H:%M")
        edatetime = datetime.strptime(info["edate"], "%Y-%m-%dT%H:%M")
        
        for data in datas:
            dsdatetime = datetime.strptime(data[1], "%Y-%m-%d %H:%M:%S")
            sedatetime = datetime.strptime(data[2], "%Y-%m-%d %H:%M:%S")
            
            if dsdatetime > sdatetime and sedatetime < edatetime:
                lists.append(calStatis(data))
        
        return jsonify({"datas": lists})

    return redirect(url_for("mainpage"))

@app.route("/getperc/<tablename>", methods = ["GET", "POST"])
def getperc(tablename):
    if request.method == "POST":
        datas = getStatis(tablename)
        
        return jsonify({"datas": datas})

    return redirect(url_for("mainpage"))

@app.route("/identify", methods = ["GET", "POST"])
def identify():
    loggedIn, lastName, permission = getLoginDetails()
    
    if "account" in session:
        if permission <= 2:
            return render_template("routes/identify.html", loggedIn = loggedIn, lastName = lastName, permission = permission)
        else:
            return redirect(url_for("mainpage"))
    else:
        return redirect(url_for("login"))

@app.route("/identify/start", methods = ["GET", "POST"])
def identify_start():
    global Batch
    
    if request.method == "POST":
        with sqlite3.connect("database.db") as conn:
            c = conn.cursor()
            c.execute("SELECT tableID FROM statis")
            Batch = len(c.fetchall()) + 1

            try:
                c.execute("INSERT INTO statis (starttime) VALUES (?)", (
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                ))

                conn.execute('''CREATE TABLE IF NOT EXISTS s'''+ str(Batch) +''' (
                    imgID INTEGER PRIMARY KEY AUTOINCREMENT,
                    percentage FLOAT,
                    thres INTEGER
                )''')
            except Exception as e:
                conn.rollback()
                print(e)

            conn.commit()

        if not path.isdir("./library/static/statis/" + str(Batch)):
            mkdir("./library/static/statis/s" + str(Batch))

        return jsonify({"test": "start"})
    else:
        return redirect(url_for("identify"))

@app.route("/identify/identify", methods = ["GET", "POST"])
def identify_identify():
    global Batch, Index, Thres, Success
    
    if request.method == "POST":
        JSONPATH = "./library/static/datas/control.json"
        percent = 0
        myjson = {"capture": False, "batch": Batch, "index": Index, "percent": 0}

        if not myjson["capture"]:
            myjson["capture"] = True
            
            with open(JSONPATH, mode="w", encoding="utf8") as f:
                f.write(json.dumps(myjson))

        while True:
            try:
                with open(JSONPATH, mode="r", encoding="utf8") as f:
                    myjson = json.load(f)
                
                if not myjson["capture"]:
                    percent = myjson["percent"]
                    
                    if percent > 0:
                        with sqlite3.connect("database.db") as conn:
                            c = conn.cursor()

                            try:
                                c.execute("INSERT INTO s"+ str(Batch) +" (percentage, thres) VALUES (?, ?)", (
                                    percent,
                                    Thres
                                ))
                            except Exception as e:
                                conn.rollback()
                                print(e)

                            conn.commit()
                        
                        Index += 1
                    
                    with open(JSONPATH, mode="w", encoding="utf8") as f:
                        f.write(json.dumps({"capture": False, "batch": Batch, "index": Index, "percent": 0}))

                    if percent > Thres:
                        Success = True
                    else:
                        Success = False

                    break
            except:
                pass

        return jsonify({"test": "identify", "batch": Batch, "index": Index, "percent": percent})
    else:
        return redirect(url_for("identify"))

@app.route("/identify/end", methods = ["GET", "POST"])
def identify_end():
    global Batch, Index
    
    if request.method == "POST":
        with sqlite3.connect("database.db") as conn:
            c = conn.cursor()

            try:
                c.execute("UPDATE statis SET endtime = ? WHERE tableID = '"+str(Batch)+"'", (
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                ))
            except Exception as e:
                conn.rollback()
                print(e)

            conn.commit()

        emailEndInfo(session["email"], "s" + str(Batch))

        Batch += 1
        Index = 0

        return jsonify({"test": "end"})
    else:
        return redirect(url_for("identify"))

@app.route("/forget", methods = ["GET", "POST"])
def forget():
    if request.method == "POST":
        info = {
            "email": request.form["email"]
        }

        with sqlite3.connect("database.db") as conn:
            c = conn.cursor()
        
        try:
            newpasswd = getRandomString(10)
            
            c.execute("UPDATE users SET passwd = ? WHERE email = '"+str(info["email"])+"'", (
                hashlib.md5(newpasswd.encode()).hexdigest(),
            ))
            conn.commit()

            sendEmail(info["email"], newpasswd)
            
            return jsonify({"data": "success"})
        except Exception as e:
            print(e)
            
            return jsonify({"data": "fail"})
    
    return redirect(url_for("login"))

@app.route("/editbatch", methods = ["GET", "POST"])
def edit_batch():
    loggedIn, lastName, permission = getLoginDetails()
    
    if "account" in session:
        return render_template("routes/editbatch.html", loggedIn = loggedIn, permission = permission, lastName = lastName)
    else:
        return redirect(url_for("login"))

@app.route("/editbatch/get", methods = ["GET", "POST"])
def editbatch_get():
    if request.method == "POST":
        datas = []
        
        with sqlite3.connect("database.db") as conn:
            c = conn.cursor()

            c.execute("SELECT * FROM statis")
            temps = c.fetchall()

            for temp in temps:
                c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='s"+ str(temp[0]) +"'")

                if len(c.fetchall()) != 0:
                    datas.append(temp)
        
        return jsonify({"datas": datas})
    return redirect(url_for("edit_batch"))

@app.route("/editbatch/del/<tablename>", methods = ["GET", "POST"])
def editbatch_del(tablename):
    if request.method == "POST":
        tablename = tablename[1]

        with sqlite3.connect("database.db") as conn:
            c = conn.cursor()

            try:
                c.execute("DROP TABLE IF EXISTS s" + str(tablename))
            except Exception as e:
                print(e)
                conn.rollback()
                return jsonify({"msg": "fail"})

            conn.commit()

        if path.isdir("./library/static/statis/s" + str(tablename)):
            rmtree("./library/static/statis/s" + str(tablename))

        return jsonify({"msg": "success"})
    
    return redirect(url_for("edit_batch"))

@app.route("/read")
def read():
    global IsMotorOn, MotorSpeed, Direct, Success

    mydict = {"isMotorOn": IsMotorOn, "speed": MotorSpeed, "direct": Direct, "success": Success}

    return json.dumps(mydict)

@app.route("/<not_define_routes>")
def myroute(not_define_routes):
    defineroutes = []

    if not_define_routes not in defineroutes:
        abort(404)

@app.errorhandler(404)
def not_found(error):
    loggedIn, lastName, permission = getLoginDetails()
    
    return render_template("routes/404.html", loggedIn = loggedIn, permission = permission, lastName = lastName), 404