from django.db import connection
from members.responses.result import Result
from members.responses.members.resMemberData import ResMemberData

def getMemberDataList():
    resMemberDataList = list()
    cursor = connection.cursor()
    cursor.execute("""
        select members.memberId, members.username, members.membername, members.phone
        from members
        where members.isEnable = 1
        order by members.memberId asc"""
    )
    data = cursor.fetchall()
    for item in data:
        resMemberDataList.append(ResMemberData(item[0], item[1], item[2], item[3]))
    return Result(True, resMemberDataList, "成功取得列表")

def getMemberData(memberId):
    cursor = connection.cursor()
    cursor.execute("""
        select members.memberId, members.username, members.membername, members.phone
        from members
        where members.memberId = %(memberId)s"""
    , { 'memberId': memberId })
    data = cursor.fetchone()
    resMemberDataList = ResMemberData(data[0], data[1], data[2], data[3])
    if(data == None):
        return Result(False, None, "取得資料錯誤")
    return Result(True, resMemberDataList, "成功取得資料")

def updateMembersData(membername, phone, memberId):
    cursor = connection.cursor()    
    cursor.execute("""
        update members
        set members.membername = %(membername)s, members.phone = %(phone)s
        where memberId = %(memberId)s"""
    ,{ 'membername': membername,'phone': phone, 'memberId': memberId })
    return Result(True, None, "成功更新資料")

def deleteMembersData(memberId):
    cursor = connection.cursor()
    cursor.execute("""
        update members
        set members.isEnable = 0
        where memberId = %(memberId)s"""
    ,{ 'memberId': memberId})
    return Result(True, None, "成功更新資料")