file_name='Tracking_202210021200'
import torch
device=torch.device('cuda') # 'cuda'/'cpu'，import torch
num_outputs=1

# 取得網路
from torch import nn
import torchvision.models as models
class Transfer_Model(nn.Module):
    def __init__(self):
        super(Transfer_Model,self).__init__()
        vgg16=models.vgg16(pretrained=True) # 使用預訓練的VGG16網路，import torchvision.models as models
        vgg16.classifier=nn.Sequential() # 將全連接層置空
        self.features=vgg16
        self.fc=nn.Sequential( # 建立新的全連接層
            nn.Linear(512*7*7,4096),
            nn.ReLU(inplace=True),
            # nn.Dropout(0.5),
            nn.Linear(4096,4096),
            nn.ReLU(inplace=True),
            # nn.Dropout(0.5),
            nn.Linear(4096,num_outputs)
        )

    def forward(self,x):
        x=self.features(x)
        x=x.view(x.size(0),-1)
        x=self.fc(x)
        return x

regressor=Transfer_Model().to(device)
regressor.load_state_dict(torch.load(file_name)) # import torch
regressor.eval()


# 取得影像
from torchvision import transforms
transforms=transforms.Compose([transforms.Resize((224,224)),transforms.ToTensor(),transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5))]) # ToTensor將影像像素歸一化至0~1(直接除以255)，from torchvision import transforms
import cv2 # 匯入cv2套件
webcam=cv2.VideoCapture(0) # 建立攝像頭物件，import cv2
from PIL import Image,ImageDraw
while True:
    success,img_cv=webcam.read() # 讀取影像，img：[480,640,3]
    I=Image.fromarray(cv2.cvtColor(img_cv,cv2.COLOR_BGR2RGB)) # from PIL import Image
    img=transforms(I) # [3,224,224]
    img=img.unsqueeze(0) # [1,3,224,224]
    img=img.to(device)

    # 預測結果
    pred=regressor(img)
    cv2.circle(img_cv,(int(pred/224*img_cv.shape[1]),int(0.26*img_cv.shape[0])),5,(0,255,0),-1)
    cv2.imshow('Frame',img_cv)
    k=cv2.waitKey(1)
