let reg_msg = document.getElementById("reg_msg").value;

if(reg_msg == "reg_nofile") {alert("[產線系統管理]\n上傳失敗\n請選擇檔案 !");}
else if(reg_msg == "reg_typeerr") {alert("[產線系統管理]\n上傳失敗\n檔案類型錯誤 !");}
else if(reg_msg == "reg_err") {alert("[產線系統管理]\n註冊失敗\n發生錯誤 !");}
else if(reg_msg == "reg_success") {alert("[產線系統管理]\n註冊成功 !");}
else if(reg_msg == "del_typeerr") {alert("[產線系統管理]\n上傳失敗\n檔案類型錯誤 !");}
else if(reg_msg == "del_err") {alert("[產線系統管理]\n刪除失敗\n發生錯誤 !");}
else if(reg_msg == "del_success") {alert("[產線系統管理]\n刪除成功 !");}
reg_msg = ""

handler();

function handler() {
    const inputs = document.querySelectorAll(".reg_input");
    for(const input of inputs) {
        input.addEventListener("keydown", (e) => {
            const usertr = input.parentElement.parentElement;

            if(e.key != "Enter") {
                usertr.classList.add("reg_edit");
            }

            if(e.key == "Enter") {
                if(usertr.classList.contains("reg_edit")) {
                    reg_edit(usertr);
                }
            }
        });
    }
}

function reg_edit(element) {
    const form_data = new FormData();

    for(let i = 0; i < element.childElementCount; i++) {
        const val = element.children[i].firstElementChild.value;;

        form_data.append(i, val);
    }

    $.ajax({
        type: "POST",
        url: $SCRIPT_ROOT + "/reg_edit",
        data: form_data,
        success: (data) => {
            if(data["msg"] == "edit_success") {
                element.classList.remove("reg_edit");
            }
        },
        contentType: false,
        processData: false,
        dataType: "json"
    });
}