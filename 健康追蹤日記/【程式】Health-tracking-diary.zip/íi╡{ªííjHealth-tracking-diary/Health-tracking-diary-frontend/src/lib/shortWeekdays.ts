export const shortWeekdays = ['日', '一', '二', '三', '四', '五', '六'];
