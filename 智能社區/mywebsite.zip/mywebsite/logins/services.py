from logins.models import admins
from django.db import connection
from logins.responses.reslogin import Reslogin
from logins.responses.result import Result

# def login_service(reqlogin):
#     data = admins.objects.filter(username = str(reqlogin.username[0])).filter(password = str(reqlogin.password)).filter(isEnable = str(1)).first()
#     if(data == None):
#         return Result(False, None, "帳密錯誤")
#     resLogin = Reslogin(data.adminId, data.adminname, data.admingroupId)
#     return Result(True, resLogin, "成功取得帳號")

def getLoginData(reqlogin):
    cursor = connection.cursor()
    cursor.execute("""
        select admins.adminId, admins.adminname, admins.admingroupId
        from admins
        where admins.isEnable = 1 And admins.username = %(username)s and admins.password = %(password)s"""
    ,{ 'username': str(reqlogin.username[0]), 'password': str(reqlogin.password) })
    data = cursor.fetchone()
    if(data == None):
        return Result(False, None, "取得列表錯誤")
    resLogin = Reslogin(data[0], data[1], data[2])
    return Result(True, resLogin, "成功取得列表")