package Core;

import java.util.ArrayList;

public class Category implements Share {

    //  --- Category Name
    public String name;
    //  --- One chain in the category
    public Chain chain;
    //  --- number of training node, max of 10000
    public int catCnt = 0;

    //  --- new a category also new a chain
    public Category(String name_) {
        name = name_;
        chain = new Chain(name);
    }

    //  --- add Node in Category will reject similar node
    public void addNode(Node newN) {
        for (Node nd : chain.nodes) {
            if (nd.similar(newN)) {
                nd.cnt++;
                return;
            }
        }
        newN.cnt++;
        chain.addNode(newN);
        // System.out.println("chain size: " + chain.nodes.size());
    }

    //  --- match and give a score to a chain
    public double matchScore(Chain other) {
        double score = 0.0;
        //  --- check every node in the matched chain
        for (Node nd : other.nodes) {
            score += nodeScore(nd);
        }
        return score;
    }

    //  --- give a score to a single node
    public double nodeScore(Node other) {
        for (Node nd : chain.nodes) {
            if (nd.similar(other)) {
                //  --- the node is in the catigory return its prob.
                if (nd.common) {
                    return nd.prob;
                } else {
                    return nd.prob * 2.0;
                }
            }
        }
        //  --- node not in the category
        return 0.0;
    }

    public void trimNodes() {
        ArrayList<Node> dList = new ArrayList<>();
        for (Node nd : chain.nodes) {
            if (nd.prob < 0.002) {
                dList.add(nd);
            }
        }
        for (Node nd : dList) {
            chain.nodes.remove(nd);
        }
        System.out.println("TrimNodes(): Cat size: " + chain.nodes.size());
    }

    //  --- trimming non representative node in the category
    public void newProb() {
        //  --- collect node to remove in a list
        //  --- sum up the number of samples in all nodes
        int sumCnt = 0;
        for (Node nd : chain.nodes) {
            sumCnt += nd.cnt;
        }
        System.out.println("sumCnt: " + sumCnt);
        //  --- cutting threshold = sample No/1000
        for (Node nd : chain.nodes) {
            nd.prob = (double) nd.cnt / (double) sumCnt;
        }
        System.out.println("NewProb(): Cat size: " + chain.nodes.size());
    }

    public void showRouph() {
        show("Category: " + name);
        show("  Chain Size: " + chain.nodes.size());
    }

    public void show(String str) {
        System.out.println(str);
    }
}
