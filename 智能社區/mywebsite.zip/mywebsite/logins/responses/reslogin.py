class Reslogin:
    def __init__(self, adminId, adminname, admingroupId) -> None:
        self.adminId = adminId,
        self.adminname = adminname,
        self.admingroupId = admingroupId