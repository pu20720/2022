package cclo;

import com.google.api.gax.rpc.ClientStream;
import com.google.api.gax.rpc.ResponseObserver;
import com.google.api.gax.rpc.StreamController;
import com.google.cloud.speech.v1.*;
import com.google.protobuf.ByteString;

import javax.sound.sampled.*;
import java.util.ArrayList;

public class RunCN {

    //static Logger logger = Logger.getLogger(RunCN.class);
    public static void main(String[] args) throws Exception {

        streamingMicRecognize();

    }

    // [START speech_transcribe_streaming_mic]
    /**
     * Performs microphone streaming speech recognition with a duration of 1
     * minute.
     */
    public static void streamingMicRecognize() throws Exception {

        ResponseObserver<StreamingRecognizeResponse> responseObserver = null;
        try ( SpeechClient client = SpeechClient.create()) {

            responseObserver
                    = new ResponseObserver<StreamingRecognizeResponse>() {
                ArrayList<StreamingRecognizeResponse> responses = new ArrayList<>();

                @Override
                public void onStart(StreamController controller) {
                }

                @Override
                public void onResponse(StreamingRecognizeResponse response) {
                    responses.add(response);
                    System.out.print("*");
                }

                @Override
                public void onComplete() {
                    for (StreamingRecognizeResponse response : responses) {
                        StreamingRecognitionResult result = response.getResultsList().get(0);
                        SpeechRecognitionAlternative alternative = result.getAlternativesList().get(0);
                        System.out.printf("Transcript : %s\n", alternative.getTranscript());

                    }
                    responses.clear();
                }

                @Override
                public void onError(Throwable t) {
                    System.out.println(t);
                }
            };

            ClientStream<StreamingRecognizeRequest> clientStream
                    = client.streamingRecognizeCallable().splitCall(responseObserver);

            RecognitionConfig recognitionConfig
                    = RecognitionConfig.newBuilder()
                            .setEncoding(RecognitionConfig.AudioEncoding.LINEAR16)
                            .setLanguageCode("zh-TW")
                            .setSampleRateHertz(16000)
                            .build();
            StreamingRecognitionConfig streamingRecognitionConfig
                    = StreamingRecognitionConfig.newBuilder().setConfig(recognitionConfig).build();

            StreamingRecognizeRequest request
                    = StreamingRecognizeRequest.newBuilder()
                            .setStreamingConfig(streamingRecognitionConfig)
                            .build(); // The first request in a streaming call has to be a config

            clientStream.send(request);
            // SampleRate:16000Hz, SampleSizeInBits: 16, Number of channels: 1, Signed: true,
            // bigEndian: false
            AudioFormat audioFormat = new AudioFormat(16000, 16, 1, true, false);
            DataLine.Info targetInfo
                    = new DataLine.Info(
                            TargetDataLine.class,
                            audioFormat); // Set the system information to read from the microphone audio stream

            if (!AudioSystem.isLineSupported(targetInfo)) {
                System.out.println("Microphone not supported");
                System.exit(0);
            }
            // Target data line captures the audio stream the microphone produces.
            TargetDataLine targetDataLine = (TargetDataLine) AudioSystem.getLine(targetInfo);
            targetDataLine.open(audioFormat);
            targetDataLine.start();
            System.out.println("請說中文");
            long startTime = System.currentTimeMillis();
            // Audio Input Stream
            AudioInputStream audio = new AudioInputStream(targetDataLine);

            while (true) {
                long currentTime = System.currentTimeMillis();
                long estimatedTime = currentTime - startTime;

                byte[] data = new byte[200];
                audio.read(data);
                request
                        = StreamingRecognizeRequest.newBuilder()
                                .setAudioContent(ByteString.copyFrom(data))
                                .build();
                clientStream.send(request);

                if (estimatedTime > 200) {
                    startTime = currentTime;
                    responseObserver.onComplete();

                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }

    }
}
