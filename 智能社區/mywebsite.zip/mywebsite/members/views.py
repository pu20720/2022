import json
from datetime import datetime, timedelta
from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.contrib.sessions.models import Session
from django.core import serializers
from members.services import getMemberDataList
from members.services import getMemberData
from members.services import updateMembersData
from members.services import deleteMembersData

# Create your views here.
def index(request):
    if 'adminId' in request.session:
        return render(request, 'members/index.html')
    else:
        return redirect('/login')

def getData(request):
    if 'adminId' in request.session:
        resDataList = []
        resData = getMemberDataList()
        for item in resData.data:
            itemInfo = {
                "memberId": item.memberId,
                "username": item.username,                
                "membername": item.membername,
                "phone": item.phone,             
                "membername": item.membername,
            }
            resDataList.append(itemInfo)
        dataDic = {}
        dataDic['data'] = resDataList
        return HttpResponse(json.dumps(dataDic))
    else:
        return redirect('/login')

def edit(request, memberId):
    if 'adminId' in request.session:
        resMemberData = getMemberData(memberId)
        return render(request,'members/edit.html', { 'resMemberData': resMemberData.data })
    else:
        return redirect('/login')

def update(request):
    if 'adminId' in request.session:
        if request.method == 'POST' and request.POST: 
            memberId = request.POST.get('memberId', '')
            membername = request.POST.get('membername', '')
            phone = request.POST.get('phone', '')
            resData = updateMembersData(membername, phone, memberId)
            if(resData.isSuccess):
                return redirect('/members/index')
            else:
                return redirect('/members/index')
        return redirect('/members/index')
    else:
        return redirect('/login')

def delete(request, memberId):
    if 'adminId' in request.session:
        deleteMembersData(memberId)
        return redirect('/members/index')
    else:
        return redirect('/login')