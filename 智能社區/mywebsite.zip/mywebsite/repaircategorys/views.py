import json
from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.contrib.sessions.models import Session
from django.core import serializers
from repaircategorys.services import getRepaircategoryDataList
from repaircategorys.services import getRepaircategoryData
from repaircategorys.services import insertRepaircategoryData
from repaircategorys.services import updateRepaircategoryData
from repaircategorys.services import deleteRepaircategoryData
from repaircategorys.requests.reqinsertrepaircategorydata import ReqInsertRepaircategoryData
from repaircategorys.requests.requpdaterepaircategorydata import ReqUpdateRepaircategoryData

# Create your views here.
def index(request):
    if 'adminId' in request.session:
        return render(request, 'repaircategorys/index.html')
    else:
        return redirect('/login')

def getData(request):
    if 'adminId' in request.session:
        resDataList = []
        resData = getRepaircategoryDataList()
        for item in resData.data:
            itemInfo = {
                "repaircategoryId": item.repaircategoryId,
                "repaircategoryname": item.repaircategoryname,
                "maxium": item.maxium
            }
            resDataList.append(itemInfo)
        dataDic = {}
        dataDic['data'] = resDataList
        return HttpResponse(json.dumps(dataDic))
    else:
        return redirect('/login')

def add(request):
    if 'adminId' in request.session:
        timeRange = range(0, 24)
        return render(request,'repaircategorys/add.html', { 'timeRange': timeRange })
    else:
        return redirect('/login')

def edit(request, repaircategoryId):
    if 'adminId' in request.session:
        timeRange = range(0, 24)
        resRepaircategoryData = getRepaircategoryData(repaircategoryId)
        return render(request,'repaircategorys/edit.html', {'resRepaircategoryData': resRepaircategoryData.data, 'timeRange': timeRange })
    else:
        return redirect('/login')

def insert(request):
    if 'adminId' in request.session:
        if request.method == 'POST' and request.POST:
            repaircategoryname = request.POST.get('repaircategoryname', '')
            maxium = request.POST.get('maxium', '')
            reqData = ReqInsertRepaircategoryData(repaircategoryname, maxium)
            resData = insertRepaircategoryData(reqData)
            if(resData.isSuccess):
                return redirect('/repaircategorys/index')
            else:
                return redirect('/repaircategorys/index')
        return redirect('/repaircategorys/index')
    else:
        return redirect('/login')

def update(request):
    if 'adminId' in request.session:
        if request.method == 'POST' and request.POST:            
            repaircategoryId = request.POST.get('repaircategoryId', '')            
            repaircategoryname = request.POST.get('repaircategoryname', '')
            maxium = request.POST.get('maxium', '')
            reqData = ReqUpdateRepaircategoryData(repaircategoryId, repaircategoryname, maxium)
            resData = updateRepaircategoryData(reqData)
            if(resData.isSuccess):
                return redirect('/repaircategorys/index')
            else:
                return redirect('/repaircategorys/index')
        return redirect('/repaircategorys/index')
    else:
        return redirect('/login')

def delete(request, repaircategoryId):
    if 'adminId' in request.session:
        deleteRepaircategoryData(repaircategoryId)
        return redirect('/repaircategorys/index')
    else:
        return redirect('/login')