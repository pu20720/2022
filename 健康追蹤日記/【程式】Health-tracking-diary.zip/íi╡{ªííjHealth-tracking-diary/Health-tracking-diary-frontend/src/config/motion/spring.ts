export const spring = {
  type: "spring",
  damping: 20,
  stiffness: 100,
  when: "afterChildren",
};
