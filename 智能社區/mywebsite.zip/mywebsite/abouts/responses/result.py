class Result:
    def __init__(self, isSuccess, data, note):
        self.isSuccess = isSuccess,
        self.data = data
        self.note = note
