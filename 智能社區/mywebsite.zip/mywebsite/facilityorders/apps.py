from django.apps import AppConfig


class FacilityordersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'facilityorders'
