class Datatable:
    def __init__(self, start, length) -> None:
        self.start = start,
        self.length = length,
        self.pageNumber = int(start/length) + 1