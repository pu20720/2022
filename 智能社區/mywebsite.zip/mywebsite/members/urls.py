from django.urls import path
from . import views

urlpatterns = [
    path('members/index/', views.index),
    path('members/getData/', views.getData),
    path('members/edit/<int:memberId>', views.edit),
    path('members/update/', views.update),
    path('members/delete/<int:memberId>', views.delete),
]