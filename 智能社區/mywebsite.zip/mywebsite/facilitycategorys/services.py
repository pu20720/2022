from django.db import connection
from facilitycategorys.responses.result import Result
from facilitycategorys.responses.facilitycategorys.resFacilitycategoryData import ResFacilitycategoryData

def getFacilitycategoryDataList():
    resFacilitycategoryDataList = list()
    cursor = connection.cursor()
    cursor.execute("""
        select facilitycategorys.facilitycategoryId, facilitycategorys.facilitycategoryname, facilitycategorys.maxium, facilitycategorys.startTime, facilitycategorys.endTime
        from facilitycategorys
        where facilitycategorys.isEnable = 1
        order by facilitycategorys.facilitycategoryId asc"""
    )
    data = cursor.fetchall()
    for item in data:
        resFacilitycategoryDataList.append(ResFacilitycategoryData(item[0], item[1], item[2], item[3], item[4]))
    return Result(True, resFacilitycategoryDataList, "成功取得列表")

def getFacilitycategoryData(facilitycategoryId):
    cursor = connection.cursor()
    cursor.execute("""
        select facilitycategorys.facilitycategoryId, facilitycategorys.facilitycategoryname, facilitycategorys.maxium, facilitycategorys.startTime, facilitycategorys.endTime
        from facilitycategorys
        where facilitycategoryId = %s"""
    ,[facilitycategoryId])
    data = cursor.fetchone()
    resFacilitycategoryData = ResFacilitycategoryData(data[0], data[1], data[2], data[3], data[4])
    if(data == None):
        return Result(False, None, "取得資料錯誤")
    return Result(True, resFacilitycategoryData, "成功取得資料")

def insertFacilitycategoryData(req):
    cursor = connection.cursor()    
    cursor.execute("""
        insert into facilitycategorys
        (facilitycategoryname, maxium, startTime, endTime, isEnable, createTime)
        values
        (%(facilitycategoryname)s, %(maxium)s, %(startTime)s, %(endTime)s, 1, now())"""
    ,{ 'facilitycategoryname': req.facilitycategoryname, 'maxium': req.maxium, 'startTime': req.startTime, 'endTime': req.endTime })
    return Result(True, None, "成功新增資料")

def updateFacilitycategoryData(req):
    cursor = connection.cursor()    
    cursor.execute("""
        update facilitycategorys
        set facilitycategorys.facilitycategoryname = %(facilitycategoryname)s, maxium = %(maxium)s, startTime = %(startTime)s, endTime = %(endTime)s
        where facilitycategoryId = %(facilitycategoryId)s"""
    ,{ 'facilitycategoryId': req.facilitycategoryId, 'maxium': req.maxium, 'facilitycategoryname': req.facilitycategoryname, 'startTime': req.startTime, 'endTime': req.endTime })
    return Result(True, None, "成功更新資料")

def deleteFacilitycategoryData(facilitycategoryId):
    cursor = connection.cursor()
    cursor.execute("""
        update facilitycategorys
        set facilitycategorys.isEnable = 0
        where facilitycategoryId = %(facilitycategoryId)s"""
    ,{ 'facilitycategoryId': facilitycategoryId})
    return Result(True, None, "成功更新資料")