import cv2
import json
import numpy as np

JSONPATH = "../static/datas/control.json"
MAXTIME = 100
MyJson = {"capture": False, "batch": 0, "index": 0, "percent": 0}

def capture() -> None:
    global JSONPATH, MAXTIME, MyJson
    
    cap = cv2.VideoCapture("http://192.168.0.26:4747/video")

    while(cap.isOpened()):
        ret, frame = cap.read()
        
        if ret:
            cv2.imshow("Cam",frame)

            try:
                with open(JSONPATH, mode="r", encoding="utf8") as f:
                    MyJson = json.load(f)

                if MyJson["capture"]:
                    for i in range(MAXTIME):
                        check = crop(frame)

                        if check:
                            break

                    MyJson["capture"] = False

                    with open(JSONPATH, mode="w", encoding="utf8") as f:
                        f.write(json.dumps(MyJson))
            except:
                pass

        else:
            break

        if cv2.waitKey(10) == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()

def crop(frame: np.ndarray) -> bool:
    global MyJson
    
    imgContour = frame.copy()
    temp = cv2.GaussianBlur(frame, (0, 0), 10)
    sharp = cv2.addWeighted(frame, 1.5, temp, -0.5, 0)
    blur = cv2.GaussianBlur(sharp, (15, 15), 0)
    canny = cv2.Canny(blur, 100, 150)
    kernel = np.ones((3, 3), np.uint8)
    dilation = cv2.dilate(canny, kernel, iterations = 1)
    contours, _ = cv2.findContours(dilation, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)

    cv2.imshow("cam", dilation)

    for cnt in contours:
        area = cv2.contourArea(cnt)
        leng = cv2.arcLength(cnt, False)

        if area > 50000 and leng < 1400:
            peri = cv2.arcLength(cnt, False)
            vertices = cv2.approxPolyDP(cnt, peri * 0.02, False)
            x, y, w, h = cv2.boundingRect(vertices)
            cv2.rectangle(imgContour, (x, y), (x+w, y+h), (255, 0, 0), 4)
            crop = frame[y:y+h, x:x+w]
            filename = "../static/statis/s" + str(MyJson["batch"]) + "/" + str(MyJson["index"])
            cv2.imwrite(filename + "_contour.png", imgContour)
            cv2.imwrite(filename + ".png", crop)
            cal(filename, crop)

            return True
    return False

def cal(filename: str, crop: np.ndarray) -> None:
    global MyJson
    
    count = 0
    lower = np.array([0, 170, 70])
    upper = np.array([179, 255, 255])

    hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, lower, upper)
    rows, cols = mask.shape

    for i in range(rows):
        for j in range(cols):
            if mask[i, j] == 255:
                count += 1

    print(str(100 - count / (rows * cols) * 100) + " %")

    MyJson["percent"] = 100 - count / (rows * cols) * 100

    cv2.imwrite(filename + "_mask.png", mask)

if __name__ == "__main__":
    capture()