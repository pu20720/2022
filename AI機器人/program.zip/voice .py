
import pyaudio 
FORMAT=pyaudio.paInt16
CHANNELS=1 
RATE=16000 
CHUNK=1024
RECORD_SECONDS=1


mic=pyaudio.PyAudio()
print('開始錄音(一秒後結束)...')
stream=mic.open(format=FORMAT,channels=CHANNELS,rate=RATE,frames_per_buffer=CHUNK,input=True)

frames=[]
for i in range(0,int(RATE/CHUNK*RECORD_SECONDS)):
    data=stream.read(CHUNK)
    frames.append(data)

print('錄音結束...')

stream.stop_stream()
stream.close()
mic.terminate()

import wave
wf = wave.open('action.wav','wb')
wf.setnchannels(CHANNELS)
wf.setsampwidth(mic.get_sample_size(FORMAT))
wf.setframerate(RATE)
wf.writeframes(b''.join(frames))
wf.close()

import librosa
y,sr=librosa.load('action.wav',sr=None)

y=y[::3] 0,3
mfccs=librosa.feature.mfcc(y,sr=16000)
import numpy as np
mfccs=np.pad(mfccs,pad_width=((0,0),(0,40-mfccs.shape[1])),mode='constant') 
np.save('x_0.npy',mfccs) 