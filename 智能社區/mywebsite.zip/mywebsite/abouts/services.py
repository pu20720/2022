import admins.models
from django.db import connection
from abouts.responses.result import Result
from abouts.responses.resAboutData import ResAboutData
from abouts.requests.requpdateaboutdata import ReqUpdateAboutData

def getAboutData(aboutId):
    cursor = connection.cursor()
    cursor.execute("""
        select abouts.aboutId, abouts.content
        from abouts
        where aboutId = %s"""
    ,[aboutId])
    data = cursor.fetchone()
    resAboutData = ResAboutData(data[0], data[1])
    if(data == None):
        return Result(False, None, "取得資料錯誤")
    return Result(True, resAboutData, "成功取得資料")

def updateAboutData(aboutId, content):
    cursor = connection.cursor()    
    cursor.execute("""
        update abouts
        set abouts.content = %(content)s
        where aboutId = %(aboutId)s"""
    ,{ 'aboutId': aboutId, 'content': content })
    return Result(True, None, "成功更新資料")