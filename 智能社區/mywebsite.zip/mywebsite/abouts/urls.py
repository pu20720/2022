from django.urls import path
from . import views

urlpatterns = [
    path('abouts/edit/<int:aboutId>', views.edit),
    path('abouts/update/', views.update),
]