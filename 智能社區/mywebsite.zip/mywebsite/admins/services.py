import admins.models
from django.db import connection
from admins.responses.result import Result
from admins.responses.admins.resAdminData import ResAdminData
from admins.responses.admingroups.resAdminGroupData import ResAdminGroupData

def getAdminDataList():
    resAdminDataList = list()
    cursor = connection.cursor()
    cursor.execute("""
        select admins.adminId, admins.username, admins.password, admins.adminname, admins.admingroupId, admingroups.admingroupname 
        from admins
        inner join admingroups on admingroups.admingroupId = admins.admingroupId
        where admins.isEnable = 1
        order by admins.adminId asc"""
    )
    data = cursor.fetchall()
    for item in data:
        resAdminDataList.append(ResAdminData(item[0], item[1], item[2], item[3], item[4], item[5]))
    if(data == None):
        return Result(False, None, "取得列表錯誤")
    return Result(True, resAdminDataList, "成功取得列表")

def getAdminData(adminId):
    cursor = connection.cursor()
    cursor.execute("""
        select admins.adminId, admins.username, admins.password, admins.adminname, admins.admingroupId, admingroups.admingroupname 
        from admins
        inner join admingroups on admingroups.admingroupId = admins.admingroupId
        where adminId = %s"""
    ,[adminId])
    data = cursor.fetchone()
    resAdminData = ResAdminData(data[0], data[1], data[2], data[3], data[4], data[5])
    if(data == None):
        return Result(False, None, "取得資料錯誤")
    return Result(True, resAdminData, "成功取得資料")

def insertAdminData(req):
    cursor = connection.cursor()    
    cursor.execute("""
        insert into admins
        (adminname, admingroupId, username, password, isEnable, createTime)
        values
        (%(adminname)s, %(admingroupId)s, %(username)s, %(password)s, 1, now())"""
    ,{ 'adminname': req.adminname, 'admingroupId': req.admingroupId, 'username': req.username, 'password': req.password})
    return Result(True, None, "成功新增資料")

def updateAdminData(req):
    cursor = connection.cursor()    
    cursor.execute("""
        update admins
        set admins.adminname = %(adminname)s, admins.admingroupId = %(admingroupId)s
        where adminId = %(adminId)s"""
    ,{ 'adminname': req.adminname, 'admingroupId': req.admingroupId, 'adminId': req.adminId})
    return Result(True, None, "成功更新資料")

def deleteAdminData(adminId):
    cursor = connection.cursor()
    cursor.execute("""
        update admins
        set admins.isEnable = 0
        where adminId = %(adminId)s"""
    ,{ 'adminId': adminId})
    return Result(True, None, "成功更新資料")

def getAdminGroupList():
    resAdminGroupData = list()
    cursor = connection.cursor()
    cursor.execute("""
        select admingroups.admingroupId, admingroups.admingroupname 
        from admingroups"""
    )
    data = cursor.fetchall()
    for item in data:
        resAdminGroupData.append(ResAdminGroupData(item[0], item[1]))
    if(data == None):
        return Result(False, None, "取得列表錯誤")
    return Result(True, resAdminGroupData, "成功取得列表")