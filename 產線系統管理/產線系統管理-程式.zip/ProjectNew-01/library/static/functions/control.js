const c_motor = document.getElementById("motor");
const c_direct = document.getElementById("direct");
const n_motorSpeed = document.getElementById("speed");
const n_thres = document.getElementById("thres");

c_motor.addEventListener("change", () => {
    $.ajax({
        type: "POST",
        url: $SCRIPT_ROOT + "/control/motor",
        data: "",
        success: (data) => {
            console.log(data["motor"]);
            c_motor.checked = data["motor"];
        },
        contentType: false,
        processData: false,
        dataType: "json"
    });
});

c_direct.addEventListener("change", () => {
    $.ajax({
        type: "POST",
        url: $SCRIPT_ROOT + "/control/direct",
        data: "",
        success: (data) => {
            console.log(data["direct"]);
            c_direct.checked = data["direct"];
        },
        contentType: false,
        processData: false,
        dataType: "json"
    });
});

n_motorSpeed.addEventListener("change", () => {
    const formData = new FormData();
    
    formData.append("speed", n_motorSpeed.value);
    
    $.ajax({
        type: "POST",
        url: $SCRIPT_ROOT + "/control/speed",
        data: formData,
        success: (data) => {
            console.log(data["speed"]);
            n_motorSpeed.value = data["speed"];
        },
        contentType: false,
        processData: false,
        dataType: "json"
    });
});

n_thres.addEventListener("change", () => {
    const formData = new FormData();
    
    formData.append("thres", n_thres.value);
    
    $.ajax({
        type: "POST",
        url: $SCRIPT_ROOT + "/control/thres",
        data: formData,
        success: (data) => {
            console.log(data["thres"]);
            n_thres.value = data["thres"];
        },
        contentType: false,
        processData: false,
        dataType: "json"
    });
});