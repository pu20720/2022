from django.db import models

# Create your models here.
class facliltycategorys(models.Model):
    facliltycategoryId = models.IntegerField(primary_key = True)
    facliltycategoryname = models.CharField(max_length = 45, primary_key = False)
    class Meta:
        db_table = "facilitycategorys"
        managed = False