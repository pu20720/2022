class ReqInsertAdminData:
    def __init__(self, adminname, admingroupId, username, password) -> None:
        self.adminname = adminname,
        self.admingroupId = admingroupId,
        self.username = username,
        self.password = password