class ResRepaircategoryData:
    def __init__(self, repaircategoryId, repaircategoryname, maxium):
        self.repaircategoryId = repaircategoryId,
        self.repaircategoryname = repaircategoryname,
        self.maxium = maxium,