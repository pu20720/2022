export class UpdateGoogleFitTargetDto {
  readonly type: '心肺強化分數' | '步數';
  readonly value: number;
}
