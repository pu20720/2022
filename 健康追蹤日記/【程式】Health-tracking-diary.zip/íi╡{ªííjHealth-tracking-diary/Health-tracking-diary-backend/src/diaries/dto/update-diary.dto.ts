import { CreateDiaryDto } from './create-diary.dto';

export class UpdateDiaryDto extends CreateDiaryDto {}
