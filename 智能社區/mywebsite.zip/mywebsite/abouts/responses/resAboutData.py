class ResAboutData:
    def __init__(self, aboutId, content) -> None:
        self.aboutId = aboutId,
        self.content = content