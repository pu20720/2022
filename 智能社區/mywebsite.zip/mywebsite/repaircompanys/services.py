from django.db import connection
from repaircompanys.responses.result import Result
from repaircompanys.responses.repaircompanys.resRepaircompanyData import ResRepaircompanyData

def getRepaircompanyDataList():
    resRepaircompanyDataList = list()
    cursor = connection.cursor()
    cursor.execute("""
        select repaircompanys.repaircompanyId, repaircompanys.repaircategoryId, repaircategorys.repaircategoryname, repaircompanys.repaircompanyname, repaircompanys.startTime, repaircompanys.endTime
        from repaircompanys
        inner join repaircategorys on repaircategorys.repaircategoryId = repaircompanys.repaircategoryId
        where repaircompanys.isEnable = 1
        order by repaircompanys.repaircompanyId asc"""
    )
    data = cursor.fetchall()
    for item in data:
        resRepaircompanyDataList.append(ResRepaircompanyData(item[0], item[1], item[2], item[3], item[4], item[5]))
    return Result(True, resRepaircompanyDataList, "成功取得列表")

def getRepaircompanyData(repaircompanyId):
    cursor = connection.cursor()
    cursor.execute("""
        select repaircompanys.repaircompanyId, repaircompanys.repaircategoryId, repaircategorys.repaircategoryname, repaircompanys.repaircompanyname, repaircompanys.startTime, repaircompanys.endTime
        from repaircompanys
        inner join repaircategorys on repaircategorys.repaircategoryId = repaircompanys.repaircategoryId
        where repaircompanyId = %s"""
    ,[repaircompanyId])
    data = cursor.fetchone()
    resRepaircompanyData = ResRepaircompanyData(data[0], data[1], data[2], data[3], data[4], data[5])
    if(data == None):
        return Result(False, None, "取得資料錯誤")
    return Result(True, resRepaircompanyData, "成功取得資料")

def insertRepaircompanyData(req):
    cursor = connection.cursor()    
    cursor.execute("""
        insert into repaircompanys
        (repaircategoryId, repaircompanyname, startTime, endTime, isEnable, createTime)
        values
        (%(repaircategoryId)s,%(repaircompanyname)s,%(startTime)s,%(endTime)s, 1, now())"""
    ,{ 'repaircategoryId': req.repaircategoryId,'repaircompanyname': req.repaircompanyname, 'startTime': req.startTime, 'endTime': req.endTime })
    return Result(True, None, "成功新增資料")

def updateRepaircompanyData(req):
    cursor = connection.cursor()    
    cursor.execute("""
        update repaircompanys
        set repaircompanys.repaircategoryId = %(repaircategoryId)s, repaircompanys.repaircompanyname = %(repaircompanyname)s, repaircompanys.startTime = %(startTime)s, repaircompanys.endTime = %(endTime)s
        where repaircompanyId = %(repaircompanyId)s"""
    ,{ 'repaircategoryId': req.repaircategoryId,'repaircompanyId': req.repaircompanyId, 'repaircompanyname': req.repaircompanyname, 'startTime': req.startTime, 'endTime': req.endTime })
    return Result(True, None, "成功更新資料")

def deleteRepaircompanyData(repaircompanyId):
    cursor = connection.cursor()
    cursor.execute("""
        update repaircompanys
        set repaircompanys.isEnable = 0
        where repaircompanyId = %(repaircompanyId)s"""
    ,{ 'repaircompanyId': repaircompanyId})
    return Result(True, None, "成功更新資料")