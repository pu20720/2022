from django.shortcuts import render, redirect
from abouts.services import getAboutData
from abouts.services import updateAboutData
from abouts.responses.resAboutData import ResAboutData
from abouts.requests.requpdateaboutdata import ReqUpdateAboutData

# Create your views here.

def edit(request, aboutId):
    if 'adminId' in request.session:
        resAboutData = getAboutData(aboutId)
        return render(request,'abouts/edit.html', { 'resAboutData': resAboutData.data })
    else:
        return redirect('/login')

def update(request):
    if 'adminId' in request.session:
        if request.method == 'POST' and request.POST:            
            aboutId = request.POST.get('aboutId', '')
            content = request.POST.get('content', '')
            resData = updateAboutData(aboutId, content)
            if(resData.isSuccess):
                return redirect(f'/abouts/edit/{aboutId}')
            else:
                return redirect(f'/abouts/edit/{aboutId}')
        return redirect(f'/abouts/edit/{aboutId}')
    else:
        return redirect('/login')