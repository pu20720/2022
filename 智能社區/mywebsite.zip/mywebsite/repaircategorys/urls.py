from django.urls import path
from . import views

urlpatterns = [
    path('repaircategorys/index/', views.index),
    path('repaircategorys/getData/', views.getData),
    path('repaircategorys/add/', views.add),
    path('repaircategorys/insert/', views.insert),
    path('repaircategorys/edit/<int:repaircategoryId>', views.edit),
    path('repaircategorys/update/', views.update),
    path('repaircategorys/delete/<int:repaircategoryId>', views.delete),
]