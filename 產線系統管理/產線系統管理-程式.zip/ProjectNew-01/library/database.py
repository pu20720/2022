import sqlite3
import hashlib

conn = sqlite3.connect("database.db")

conn.execute('''CREATE TABLE IF NOT EXISTS users (
    userID INTEGER PRIMARY KEY AUTOINCREMENT,
    firstname TEXT,
    lastname TEXT,
    account TEXT,
    passwd TEXT,
    birth TEXT,
    email TEXT,
    permission INTEGER
)''')

conn.execute('''CREATE TABLE IF NOT EXISTS statis (
    tableID INTEGER PRIMARY KEY AUTOINCREMENT,
    starttime DATE,
    endtime DATE 
)''')

with sqlite3.connect("database.db") as conn:
    c = conn.cursor()
    c.execute("SELECT userID FROM users")
    users = c.fetchall()

    if len(users) == 0:
        c.execute("INSERT INTO users (firstname, lastname, account, passwd, birth, email, permission) VALUES (?, ?, ?, ?, ?, ?, ?)", (
            "root",
            "root", 
            "IAmRoot",
            hashlib.md5("12345".encode()).hexdigest(),
            "",
            "root@root.com",
            0
        ))
        conn.commit()

conn = sqlite3.connect("log.db")

conn.execute('''CREATE TABLE IF NOT EXISTS login (
    loginID INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT,
    status TEXT,
    time DATE
)''')

conn.execute('''CREATE TABLE IF NOT EXISTS control (
    controlID INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT,
    type TEXT,
    time DATE
)''')

conn.execute('''CREATE TABLE IF NOT EXISTS edit (
    editID INTEGER PRIMARY KEY AUTOINCREMENT,
    SMemail TEXT,
    USemail TEXT,
    time DATE
)''')