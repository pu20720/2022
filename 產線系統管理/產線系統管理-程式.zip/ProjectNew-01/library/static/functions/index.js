const slides = document.querySelectorAll(".slide");
let myInterval = true;
let index = 0;

document.getElementById("main_img").addEventListener("mouseenter", () => {
    myInterval = false;
});
document.getElementById("main_img").addEventListener("mouseleave", () => {
    myInterval = true;
});

setInterval(function() {
    if(myInterval) {
        slides[index].classList.remove("activate");
        
        index++;
        index = index % slides.length

        slides[index].classList.add("activate");
    }
}, 4500);