<div class="social">
    <a href="#">分享到FB</a><br>
    <a href="#">分享到Twitter</a>
</div>