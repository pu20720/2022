const stime = document.getElementById("stime");
const etime = document.getElementById("etime");

etime.addEventListener("change", () => {
    const form_data = new FormData();

    form_data.append("sdate", stime.value);
    form_data.append("edate", etime.value);
    
    $.ajax({
        type: "POST",
        url: $SCRIPT_ROOT + "/getchartdata",
        data: form_data,
        success: (data) => {
            drawChart(data["datas"], true);
        },
        contentType: false,
        processData: false,
        dataType: "json"
    });
});

$.ajax({
    type: "POST",
    url: $SCRIPT_ROOT + "/initchartdata",
    data: "",
    success: (data) => {
        drawChart(data["datas"], false);
        getInfo();
    },
    contentType: false,
    processData: false,
    dataType: "json"
});

function drawChart(datas, isupdate) {
    console.log(datas);
    
    const data = {
        labels: [],
        datasets: [{
            label: "FAIL",
            backgroundColor: "#ff66ff",
            borderColor: "transparent",
            data: [],
        }, {
            label: "SUCCESS",
            backgroundColor: "#66ff66",
            borderColor: "transparent",
            data: [],
        }]
    };
    
    const config = {
        type: "bar",
        data: data,
        options: {
            maintainAspectRatio: false,
            layout: {
                padding: 20
            }
        }
    };

    let leng = 0;

    leng = datas.length;

    if(leng < 5) {
        for(let i = leng; i < 5; i++) {
            datas.unshift({"tablename": "", "success": 0, "fail": 0});
        }
    }

    config.data.labels = [];
    config.data.datasets[0].data = [];
    config.data.datasets[1].data = [];

    for(let i = 0; i < 5; i++) {
        config.data.labels.push(datas[i]["tablename"]);
        config.data.datasets[0].data.push(datas[i]["fail"]);
        config.data.datasets[1].data.push(datas[i]["success"]);
    }

    let barchart = Chart.getChart("myChart");
    
    if(barchart == null) {
        barchart = new Chart(
            document.getElementById("myChart"),
            config
        );
    }

    if(isupdate) { 
        barchart.data = data;
        barchart.update();
    }
}

function getInfo() {
    function setimg(perc, label, tbody) {
        const imgfiles = ["_contour.png", ".png", "_mask.png"];
        
        for(let i = 0; i < perc.length; i++) {
            const tr = document.createElement("tr");

            for(const imgfile of imgfiles) {
                const img = document.createElement("img");
                const td = document.createElement("td");
                img.src = "./../../static/statis/" + label + "/" + i + imgfile;
                td.appendChild(img);
                tr.appendChild(td);
            }

            const td = document.createElement("td");
            td.appendChild(document.createTextNode(perc[i]));
            tr.appendChild(td);

            tbody.appendChild(tr);
        }
    }
    
    const ctx = document.getElementById("myChart");
    const mychart = Chart.getChart("myChart");
    
    ctx.addEventListener("click", (e) => {
        const points = mychart.getElementsAtEventForMode(e, "nearest", {intersect: true}, true);

        if(points[0]) {
            const label = mychart.config.data.labels[points[0].index];
            const fail = mychart.config.data.datasets[0].data[points[0].index];
            const success = mychart.config.data.datasets[1].data[points[0].index];
            const tbody = document.getElementById("main_imgs");
            let perc = [];

            while(tbody.firstElementChild) { tbody.removeChild(tbody.firstElementChild); }

            $.ajax({
                type: "POST",
                url: $SCRIPT_ROOT + "/getperc/" + label,
                data: "",
                success: (data) => {
                    perc = data["datas"];
                    setimg(perc, label, tbody);
                },
                contentType: false,
                processData: false,
                dataType: "json"
            });
        }
    });
}