from django.shortcuts import redirect, render
from django.contrib.sessions.models import Session

# Create your views here.
def home(request):
    if 'adminId' in request.session:
        return render(request, 'home/index.html')
    else:
        return redirect('/login')