import { CreateTargetDto } from './create-target.dto';

export class UpdateTargetDto extends CreateTargetDto {}
