from django.db import connection
from facilityorders.responses.result import Result
from facilityorders.responses.facilityorders.resFacilityorderData import ResFacilityorderData

def getFacilityorderDataList():
    resFacilityorderDataList = list()
    cursor = connection.cursor()
    cursor.execute("""
        select facilityorders.facilityorderId, DATE_FORMAT(facilityorders.reserveTime, "%Y/%e/%c %H:%i") as reserveTime, facilityorders.reserveQuantity, facilitycategorys.facilitycategoryname, members.membername
        from facilityorders
        inner join members on members.memberId = facilityorders.memberId
        inner join facilitycategorys on facilitycategorys.facilitycategoryId = facilityorders.facilitycategoryId
        where facilityorders.isEnable = 1
        order by facilityorders.facilityorderId asc"""
    )
    data = cursor.fetchall()
    for item in data:
        resFacilityorderDataList.append(ResFacilityorderData(item[0], item[1], item[2], item[3], item[4]))
    return Result(True, resFacilityorderDataList, "成功取得列表")

def getFacilityorderData(facilityorderId):
    cursor = connection.cursor()
    cursor.execute("""
        select facilityorders.facilityorderId, facilityorders.reserveTime, facilityorders.reserveQuantity, facilitycategorys.facilitycategoryname, members.membername
        from facilityorders
        inner join members on members.memberId = facilityorders.memberId
        inner join facilitycategorys on facilitycategorys.facilitycategoryId = facilityorders.facilitycategoryId
        where facilityorderId = %s"""
    ,[facilityorderId])
    data = cursor.fetchone()
    resFacilityorderData = ResFacilityorderData(data[0], data[1], data[2], data[3], data[4], data[5])
    if(data == None):
        return Result(False, None, "取得資料錯誤")
    return Result(True, resFacilityorderData, "成功取得資料")

def deleteFacilityorderData(facilityorderId):
    cursor = connection.cursor()
    cursor.execute("""
        update facilityorders
        set facilityorders.isEnable = 0
        where facilityorderId = %(facilityorderId)s"""
    ,{ 'facilityorderId': facilityorderId})
    return Result(True, None, "成功更新資料")