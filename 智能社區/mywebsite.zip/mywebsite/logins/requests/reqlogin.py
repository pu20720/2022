class Reqlogin:
    def __init__(self, username, password) -> None:
        self.username = username,
        self.password = password