import json
from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.contrib.sessions.models import Session
from django.core import serializers
from facilitycategorys.services import getFacilitycategoryDataList
from facilitycategorys.services import getFacilitycategoryData
from facilitycategorys.services import insertFacilitycategoryData
from facilitycategorys.services import updateFacilitycategoryData
from facilitycategorys.services import deleteFacilitycategoryData
from facilitycategorys.requests.reqinsertfacilitycategorydata import ReqInsertFacilitycategoryData
from facilitycategorys.requests.requpdatefacilitycategorydata import ReqUpdateFacilitycategoryData

# Create your views here.
def index(request):
    if 'adminId' in request.session:
        return render(request, 'facilitycategorys/index.html')
    else:
        return redirect('/login')

def getData(request):
    if 'adminId' in request.session:
        resDataList = []
        resData = getFacilitycategoryDataList()
        for item in resData.data:
            itemInfo = {
                "facilitycategoryId": item.facilitycategoryId,
                "facilitycategoryname": item.facilitycategoryname,
                "openingTime": f"{item.startTime[0]}:00-{item.endTime}:00",
                "maxium": item.maxium
            }
            resDataList.append(itemInfo)
        dataDic = {}
        dataDic['data'] = resDataList
        return HttpResponse(json.dumps(dataDic))
    else:
        return redirect('/login')

def add(request):
    if 'adminId' in request.session:
        timeRange = range(0, 24)
        return render(request,'facilitycategorys/add.html', { 'timeRange': timeRange })
    else:
        return redirect('/login')

def edit(request, facilitycategoryId):
    if 'adminId' in request.session:
        timeRange = range(0, 24)
        resFacilitycategoryData = getFacilitycategoryData(facilitycategoryId)
        return render(request,'facilitycategorys/edit.html', {'resFacilitycategoryData': resFacilitycategoryData.data, 'timeRange': timeRange })
    else:
        return redirect('/login')

def insert(request):
    if 'adminId' in request.session:
        if request.method == 'POST' and request.POST:
            facilitycategoryname = request.POST.get('facilitycategoryname', '')
            maxium = request.POST.get('maxium', '')
            startTime = request.POST.get('startTime', '')
            endTime = request.POST.get('endTime', '')
            reqData = ReqInsertFacilitycategoryData(facilitycategoryname, maxium, startTime, endTime)
            resData = insertFacilitycategoryData(reqData)
            if(resData.isSuccess):
                return redirect('/facilitycategorys/index')
            else:
                return redirect('/facilitycategorys/index')
        return redirect('/facilitycategorys/index')
    else:
        return redirect('/login')

def update(request):
    if 'adminId' in request.session:
        if request.method == 'POST' and request.POST:            
            facilitycategoryId = request.POST.get('facilitycategoryId', '')            
            facilitycategoryname = request.POST.get('facilitycategoryname', '')
            startTime = request.POST.get('startTime', '')
            endTime = request.POST.get('endTime', '')
            maxium = request.POST.get('maxium', '')
            reqData = ReqUpdateFacilitycategoryData(facilitycategoryId, facilitycategoryname, maxium, startTime, endTime)
            resData = updateFacilitycategoryData(reqData)
            if(resData.isSuccess):
                return redirect('/facilitycategorys/index')
            else:
                return redirect('/facilitycategorys/index')
        return redirect('/facilitycategorys/index')
    else:
        return redirect('/login')

def delete(request, facilitycategoryId):
    if 'adminId' in request.session:
        deleteFacilitycategoryData(facilitycategoryId)
        return redirect('/facilitycategorys/index')
    else:
        return redirect('/login')