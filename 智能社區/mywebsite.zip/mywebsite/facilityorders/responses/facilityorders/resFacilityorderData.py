class ResFacilityorderData:
    def __init__(self, facilityorderId, reserveTime, reserveQuantity, facilitycategoryname, membername):
        self.facilityorderId = facilityorderId,
        self.reserveTime = reserveTime,
        self.reserveQuantity = reserveQuantity,
        self.facilitycategoryname = facilitycategoryname,
        self.membername = membername