class ReqInsertRepaircategoryData:
    def __init__(self, repaircategoryname, maxium):
        self.repaircategoryname = repaircategoryname,
        self.maxium = maxium