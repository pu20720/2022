let edit_msg = document.getElementById("edit_msg").value;

if(edit_msg == "edit_fail") { alert("[產線系統管理]\n修改失敗\n發生錯誤 !"); }
else if(edit_msg == "edit_emailalready") { alert("[產線系統管理]\n修改失敗\n已有相同信箱 !"); }
else if(edit_msg == "edit_passwderr") { alert("[產線系統管理]\n修改失敗\n密碼確認不符 !"); }
edit_msg = ""