from django.db import connection
from recognitionrecords.responses.result import Result
from recognitionrecords.responses.recognitionrecords.recognitionrecord import Recognitionrecord

def getRecognitionrecordDataList():
    recognitionrecordList = list()
    cursor = connection.cursor()
    cursor.execute("""
        select members.membername, recognitionrecords.resolution, recognitionrecords.imgPath, recognitionrecords.createTime
        from recognitionrecords
        inner join members on members.memberId = recognitionrecords.memberId
        where members.isEnable = 1
        order by recognitionrecords.recognitionrecordId asc"""
    )
    data = cursor.fetchall()
    for item in data:
        recognitionrecordList.append(Recognitionrecord(item[0], item[1], item[2], item[3]))
    return Result(True, recognitionrecordList, "成功取得列表")