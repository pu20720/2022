import json
from datetime import datetime, timedelta
from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.contrib.sessions.models import Session
from django.core import serializers
from repairorders.services import getRepairorderDataList
from repairorders.services import getRepairorderData
from repairorders.services import updateRepairorderprice
from repairorders.services import deleteRepairorderData

# Create your views here.
def index(request):
    if 'adminId' in request.session:
        return render(request, 'repairorders/index.html')
    else:
        return redirect('/login')

def getData(request):
    if 'adminId' in request.session:
        resDataList = []
        resData = getRepairorderDataList()
        for item in resData.data:
            itemInfo = {
                "repairorderId": item.repairorderId,                
                "reserveTime": item.reserveTime[0],
                "repaircompanyname": item.repaircompanyname,
                "repaircategoryname": item.repaircategoryname,                
                "membername": item.membername,
                "price": item.price
            }
            resDataList.append(itemInfo)
        dataDic = {}
        dataDic['data'] = resDataList
        return HttpResponse(json.dumps(dataDic))
    else:
        return redirect('/login')

def edit(request, repairorderId):
    if 'adminId' in request.session:
        resRepairorderData = getRepairorderData(repairorderId)
        return render(request, 'repairorders/edit.html' , {'resRepairorderData': resRepairorderData.data})
    else:
        return redirect('/login')

def update(request):
    if 'adminId' in request.session:
        if request.method == 'POST' and request.POST:            
            repairorderId = request.POST.get('repairorderId', '')            
            price = request.POST.get('price', '')
            resData = updateRepairorderprice(repairorderId, price)
            if(resData.isSuccess):
                return redirect('/repairorders/index')
            else:
                return redirect('/repairorders/index')
        return redirect('/repairorders/index')
    else:
        return redirect('/login')

def delete(request, repairorderId):
    if 'adminId' in request.session:
        deleteRepairorderData(repairorderId)
        return redirect('/repairorders/index')
    else:
        return redirect('/login')

