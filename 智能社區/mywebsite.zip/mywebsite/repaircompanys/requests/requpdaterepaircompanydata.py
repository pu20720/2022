class ReqUpdateRepaircompanyData:
    def __init__(self, repaircompanyId, repaircategoryId, repaircompanyname, startTime, endTime):
        self.repaircompanyId = repaircompanyId,
        self.repaircategoryId = repaircategoryId,
        self.repaircompanyname = repaircompanyname,
        self.startTime = startTime,
        self.endTime = endTime,