from django.urls import path
from . import views

urlpatterns = [
    path('facilitycategorys/index/', views.index),
    path('facilitycategorys/getData/', views.getData),
    path('facilitycategorys/add/', views.add),
    path('facilitycategorys/insert/', views.insert),
    path('facilitycategorys/edit/<int:facilitycategoryId>', views.edit),
    path('facilitycategorys/update/', views.update),
    path('facilitycategorys/delete/<int:facilitycategoryId>', views.delete),
]