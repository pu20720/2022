class Recognitionrecord:
    def __init__(self, membername, resolution, imgPath, createTime):
        self.membername = membername,
        self.resolution = resolution,
        self.imgPath = imgPath,
        self.createTime = createTime,