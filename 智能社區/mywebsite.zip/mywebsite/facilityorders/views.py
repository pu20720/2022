import json
from datetime import datetime, timedelta
from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.contrib.sessions.models import Session
from django.core import serializers
from facilityorders.services import getFacilityorderDataList
from facilityorders.services import getFacilityorderData
from facilityorders.services import deleteFacilityorderData

# Create your views here.
def index(request):
    if 'adminId' in request.session:
        return render(request, 'facilityorders/index.html')
    else:
        return redirect('/login')

def getData(request):
    if 'adminId' in request.session:
        resDataList = []
        resData = getFacilityorderDataList()
        for item in resData.data:
            print(item.reserveTime)
            itemInfo = {
                "facilityorderId": item.facilityorderId,                
                "reserveTime": f"{datetime.strptime(item.reserveTime[0], '%Y/%d/%m %H:%M')} - {datetime.strptime(item.reserveTime[0], '%Y/%d/%m %H:%M') + timedelta(hours=1)}",
                "facilitycategoryname": item.facilitycategoryname,
                "membername": item.membername
            }
            resDataList.append(itemInfo)
        dataDic = {}
        dataDic['data'] = resDataList
        return HttpResponse(json.dumps(dataDic))
    else:
        return redirect('/login')

def delete(request, facilityorderId):
    if 'adminId' in request.session:
        deleteFacilityorderData(facilityorderId)
        return redirect('/facilityorders/index')
    else:
        return redirect('/login')