package cclo;


import static cclo.ControlPan.toaster;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class RecordFrame extends JFrame {

    Main pMain;
    JFrame ss= new JFrame("sssss");
    ImageIcon ib = new ImageIcon("./textbook2.png");
    JButton save = new JButton(ib);
   
    ImageIcon ii = new ImageIcon("./mic.png");
     JButton record = new JButton(ii);
      ImageIcon aaa = new ImageIcon("./title.jpg");
     JLabel title1 =new JLabel(aaa);
     
    JTextArea ta = new JTextArea("");
    JScrollPane scp = new JScrollPane(ta);
    JScrollBar sbar = scp.getVerticalScrollBar();
    public RecordFrame(Main main_) {
      
        pMain = main_;
        
        this.setBounds(50, 50, 1000, 800);
       Font font = new Font("標楷體", Font.TRUETYPE_FONT, 24);
        Container container = this.getContentPane();
        container.setLayout(new BorderLayout());
        record.setBackground(new Color(255,227,132));
        save.setBackground(new Color(255,227,132));
        
        title1.setBorder(BorderFactory.createLineBorder(new Color(255,227,132)));
        record.setBorder(BorderFactory.createLineBorder(new Color(255,227,132)));
        save.setBorder(BorderFactory.createLineBorder(new Color(255,227,132)));
        
        container.add(record,BorderLayout.WEST);
        container.add(save, BorderLayout.EAST);
        container.add(title1, BorderLayout.NORTH);
        ta.setBorder(BorderFactory.createLineBorder(new Color(245,222,179)));
        ta.setBackground(new Color(245,222,179));
        record.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent ae) {
                pMain.controlPan.loadAndMatch();
            }
        });
        save.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
                savee();
            }
        });
        
        container.add(scp, BorderLayout.CENTER);
        
        
    }

    public void append(String str) {
        Font font = new Font("標楷體", Font.TRUETYPE_FONT, 24);
        ta.setFont(font);
        
        ta.append(str);
        ta.setCaretPosition(ta.getDocument().getLength());

    }

    public void savee() {
        BufferedWriter bw = null;

        try {

            OutputStream os = new FileOutputStream("./文字記錄.txt");

            bw = new BufferedWriter(new OutputStreamWriter(os));
            Font font = new Font("標楷體", Font.TRUETYPE_FONT, 24);
             ((Toaster) toaster).showToaster("儲存文字檔");
            for (String value : ta.getText().split("\n")) {
                
                bw.write(value);
                ta.setFont(font);
                bw.newLine();

            }

        } catch (IOException e1) {
        } finally {

            if (bw != null) {

                try {

                    bw.close();

                } catch (IOException e1) {
                }

            }
        }
    }
    
}
