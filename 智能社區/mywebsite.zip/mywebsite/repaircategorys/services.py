from django.db import connection
from repaircategorys.responses.result import Result
from repaircategorys.responses.repaircategorys.resRepaircategoryData import ResRepaircategoryData

def getRepaircategoryDataList():
    resRepaircategoryDataList = list()
    cursor = connection.cursor()
    cursor.execute("""
        select repaircategorys.repaircategoryId, repaircategorys.repaircategoryname, repaircategorys.maxium
        from repaircategorys
        where repaircategorys.isEnable = 1
        order by repaircategorys.repaircategoryId asc"""
    )
    data = cursor.fetchall()
    for item in data:
        resRepaircategoryDataList.append(ResRepaircategoryData(item[0], item[1], item[2]))
    return Result(True, resRepaircategoryDataList, "成功取得列表")

def getRepaircategoryData(repaircategoryId):
    cursor = connection.cursor()
    cursor.execute("""
        select repaircategorys.repaircategoryId, repaircategorys.repaircategoryname, repaircategorys.maxium
        from repaircategorys
        where repaircategoryId = %s"""
    ,[repaircategoryId])
    data = cursor.fetchone()
    resRepaircategoryData = ResRepaircategoryData(data[0], data[1], data[2])
    if(data == None):
        return Result(False, None, "取得資料錯誤")
    return Result(True, resRepaircategoryData, "成功取得資料")

def insertRepaircategoryData(req):
    cursor = connection.cursor()    
    cursor.execute("""
        insert into repaircategorys
        (repaircategoryname, maxium, isEnable, createTime)
        values
        (%(repaircategoryname)s, %(maxium)s, 1, now())"""
    ,{ 'repaircategoryname': req.repaircategoryname, 'maxium': req.maxium })
    return Result(True, None, "成功新增資料")

def updateRepaircategoryData(req):
    cursor = connection.cursor()    
    cursor.execute("""
        update repaircategorys
        set repaircategorys.repaircategoryname = %(repaircategoryname)s, repaircategorys.maxium = %(maxium)s
        where repaircategoryId = %(repaircategoryId)s"""
    ,{ 'repaircategoryId': req.repaircategoryId, 'repaircategoryname': req.repaircategoryname, 'maxium': req.maxium })
    return Result(True, None, "成功更新資料")

def deleteRepaircategoryData(repaircategoryId):
    cursor = connection.cursor()
    cursor.execute("""
        update repaircategorys
        set repaircategorys.isEnable = 0
        where repaircategoryId = %(repaircategoryId)s"""
    ,{ 'repaircategoryId': repaircategoryId})
    return Result(True, None, "成功更新資料")