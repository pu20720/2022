file_name='r'
import torch
device=torch.device('cpu') 
num_classes=4
batch_size=2
learning_rate=0.0001
step_size=1000 
epochs=100
TrainingVoice='C:'

import os
all_voice_name=os.listdir(TrainingVoice) 
V=list()
L=list()
import numpy
for i in range(0,len(all_voice_name)):
    files=os.listdir(TrainingVoice+all_voice_name[i]) 
    for j in range(0,len(files)):
        V_=torch.tensor(numpy.load(os.path.join(TrainingVoice,all_voice_name[i],files[j]))) 
        V_=V_.unsqueeze(0) 
        V.append(V_)
        L.append(i)
V=torch.stack(V,0) 10,1,40
L=torch.tensor(L) 

from torch import nn
class Simple_Model(nn.Module):
    def __init__(self):
        super().__init__()
        self.block_1=nn.Sequential(
            nn.Conv2d(in_channels=1,out_channels=32,kernel_size=2,padding=1), 
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2,stride=2), 
        )
        self.fc=nn.Sequential(
            nn.Linear(32*10*20,128),
            nn.ReLU(inplace=True),
            nn.Linear(128,num_classes),
        )
    def forward(self,x):
        x=self.block_1(x) 
        x=x.view(x.size(0),-1)
        x=self.fc(x)
        return x

classifier=Simple_Model().to(device)
criterion=nn.CrossEntropyLoss() 
optimizer=torch.optim.Adam(classifier.parameters(),lr=learning_rate) 
scheduler=torch.optim.lr_scheduler.StepLR(optimizer,step_size,0.1) 
train_acc_his,train_losses_his=[],[]
for i in range(1,epochs+1):
    print('Running Epoch:'+str(i))
    p=numpy.random.permutation(len(V)) 
    V=V[[p]]
    L=L[p]
    train_correct,train_loss,train_total=0,0,0,1
    classifier.train()
    for j in range(0,len(V),batch_size):
        voice=V[[numpy.arange(j,j+batch_size)]] 
        cls=L[numpy.arange(j,j+batch_size)] 
        voice,cls=voice.to(device),cls.to(device)
        pred=classifier(voice)pred： 
        loss=criterion(pred,cls) 
        output_id=torch.max(pred,dim=1)[1] 
        train_correct+=numpy.sum(torch.eq(cls,output_id).cpu().numpy()) 
        train_loss+=loss.item()*voice.size(0) 
        train_total+=voice.size(0) 
        optimizer.zero_grad() 
        loss.backward() 
        optimizer.step()  
    scheduler.step()

    train_acc=train_correct/train_total*100 
    train_loss=train_loss/train_total 
    train_acc_his.append(train_acc) 
    train_losses_his.append(train_loss) 
    print('Training Loss='+str(train_loss))
    print('Training Accuracy(%)='+str(train_acc))


torch.save(classifier.state_dict(),file_name)