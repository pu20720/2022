def stop(change):
    robot.stop()
    
def step_forward(change):
    robot.forward(0.3)
    time.sleep(0.1)
    robot.stop()

def step_backward(change):
    robot.backward(0.3)
    time.sleep(0.1)
    robot.stop()

def step_left(change):
    robot.left(0.24)
    time.sleep(0.05)
    robot.stop()

def step_right(change):
    robot.right(0.24)
    time.sleep(0.05)
    robot.stop()