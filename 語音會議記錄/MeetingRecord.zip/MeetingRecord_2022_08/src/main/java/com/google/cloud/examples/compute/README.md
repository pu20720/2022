[**DEPRECATED**]

The compute samples have been moved to [Java-docs-samples repository](https://github.com/GoogleCloudPlatform/java-docs-samples/tree/main/compute/cloud-client).
